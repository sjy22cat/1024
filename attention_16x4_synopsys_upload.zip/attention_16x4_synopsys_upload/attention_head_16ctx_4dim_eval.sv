`timescale 1ns/1ps

// Single-query/head evaluation unit: 16 context rows x 4 dimension columns.
// Defaults: Q[128], 512 context tokens/wave, 64 logical 32x32 MAC planes.
// KV_LOAD_PARALLEL 32x128 FP32 K/V tiles are accepted per handshake. Next-wave loading
// overlaps the current wave's context/running merge, reusing the K/V banks.
// This is an FP32 architectural evaluator, not a wrapper
// around the MXFP4 physical array or a complete sixteen-head scheduler.
module attention_head_16ctx_4dim_eval #(
    parameter integer HEAD_DIM = 128,
    parameter integer TILE_SIZE = 32,
    parameter integer MAX_CONTEXT = 1152,
    parameter integer CONTEXT_PARALLEL = 16,
    parameter integer KV_LOAD_PARALLEL = 16,
    parameter [31:0] SCALE_BITS = 32'h3db504f3
) (
    input wire clk, rst_n,
    input wire i_cmd_valid,
    output wire o_cmd_ready,
    input wire [10:0] i_context_len,
    input wire [HEAD_DIM*32-1:0] i_query,
    input wire i_kv_valid,
    output wire o_kv_ready,
    input wire [KV_LOAD_PARALLEL*TILE_SIZE*HEAD_DIM*32-1:0] i_key_tile, i_value_tile,
    output wire o_valid,
    input wire i_ready,
    output wire [HEAD_DIM*32-1:0] o_result,
    output reg o_error,
    output reg [31:0] o_cycle_count
);
    localparam integer S_IDLE=0, S_QUERY_SCALE=1, S_LOAD=2, S_LAUNCH=3,
        S_WAIT=4, S_INV=5, S_NORMALIZE=6, S_RESPONSE=7;
    localparam integer LOAD_W = (CONTEXT_PARALLEL <= 1) ? 1 : $clog2(CONTEXT_PARALLEL);
    reg [2:0] state;
    reg [10:0] context_q, loaded_q;
    reg [LOAD_W-1:0] load_lane_q;
    reg [CONTEXT_PARALLEL-1:0] active_q;
    reg load_complete_q, prefetch_open_q, wave_final_q;
    reg [HEAD_DIM*32-1:0] query_q, query_scaled_q, result_q;
    reg running_present_q;
    reg [31:0] running_m_q, running_l_q, inverse_q;
    reg [HEAD_DIM*32-1:0] running_z_q;

    initial begin
        if (HEAD_DIM != 4*TILE_SIZE || TILE_SIZE < 2 || TILE_SIZE > 32 ||
            (TILE_SIZE & (TILE_SIZE-1)) != 0 || MAX_CONTEXT < 1 || MAX_CONTEXT > 2047 ||
            KV_LOAD_PARALLEL < 1 || KV_LOAD_PARALLEL > CONTEXT_PARALLEL ||
            CONTEXT_PARALLEL % KV_LOAD_PARALLEL != 0 ||
            CONTEXT_PARALLEL < 2 || (CONTEXT_PARALLEL & (CONTEXT_PARALLEL-1)) != 0)
            $fatal(1, "invalid 16ctx/4dim Attention configuration");
    end
    assign o_cmd_ready = state == S_IDLE;
    wire [CONTEXT_PARALLEL-1:0] lane_done, lane_present;
    wire lanes_done = &lane_done;
    assign o_kv_ready = (state == S_LOAD ||
        (state == S_WAIT && (prefetch_open_q || lanes_done))) &&
        !load_complete_q && loaded_q < context_q;
    wire kv_accept = o_kv_ready && i_kv_valid;
    wire load_finishes_wave = load_lane_q + KV_LOAD_PARALLEL >= CONTEXT_PARALLEL ||
        ({1'b0,loaded_q}+KV_LOAD_PARALLEL*TILE_SIZE >= {1'b0,context_q});
    assign o_valid = state == S_RESPONSE;
    assign o_result = result_q;

    wire [HEAD_DIM*32-1:0] query_scaled, normalized;
    wire [31:0] inverse;
    wire [7:0] inv_status;
    DW_fp_div #(.sig_width(23), .exp_width(8), .ieee_compliance(0), .faithful_round(0)) u_inv (
        .a(32'h3f800000), .b(running_l_q), .rnd(3'b000), .z(inverse), .status(inv_status));
    genvar d;
    generate for (d=0; d<HEAD_DIM; d=d+1) begin : g_dim
        wire [7:0] sq, so;
        DW_fp_mult #(.sig_width(23), .exp_width(8), .ieee_compliance(0)) u_query_scale (
            .a(query_q[d*32 +: 32]), .b(SCALE_BITS), .rnd(3'b000),
            .z(query_scaled[d*32 +: 32]), .status(sq));
        DW_fp_mult #(.sig_width(23), .exp_width(8), .ieee_compliance(0)) u_output_scale (
            .a(running_z_q[d*32 +: 32]), .b(inverse_q), .rnd(3'b000),
            .z(normalized[d*32 +: 32]), .status(so));
    end endgenerate

    wire [KV_LOAD_PARALLEL*TILE_SIZE-1:0] load_mask;
    genvar t;
    generate for (t=0; t<KV_LOAD_PARALLEL*TILE_SIZE; t=t+1) begin : g_load_mask
        assign load_mask[t] = ({1'b0,loaded_q} + t) < {1'b0,context_q};
    end endgenerate

    wire [CONTEXT_PARALLEL*32-1:0] lane_m, lane_l;
    wire [CONTEXT_PARALLEL*HEAD_DIM*32-1:0] lane_z;
    wire context_fire, context_present;
    wire [31:0] context_m, context_l;
    wire [HEAD_DIM*32-1:0] context_z;
    genvar c;
    generate
        for (c=0; c<CONTEXT_PARALLEL; c=c+1) begin : g_context
            attention_context_4dim_lane #(.HEAD_DIM(HEAD_DIM), .TILE_SIZE(TILE_SIZE)) u_lane (
                .clk(clk), .rst_n(rst_n),
                .i_load(kv_accept && c >= load_lane_q && c < load_lane_q + KV_LOAD_PARALLEL),
                .i_token_mask(load_mask[(c%KV_LOAD_PARALLEL)*TILE_SIZE+:TILE_SIZE]),
                .i_key(i_key_tile[(c%KV_LOAD_PARALLEL)*TILE_SIZE*HEAD_DIM*32+:TILE_SIZE*HEAD_DIM*32]),
                .i_value(i_value_tile[(c%KV_LOAD_PARALLEL)*TILE_SIZE*HEAD_DIM*32+:TILE_SIZE*HEAD_DIM*32]),
                .i_start(state == S_LAUNCH), .i_active(active_q[c]),
                .i_query_scaled(query_scaled_q),
                .o_done(lane_done[c]), .o_present(lane_present[c]),
                .o_m(lane_m[c*32+:32]), .o_l(lane_l[c*32+:32]),
                .o_z(lane_z[c*HEAD_DIM*32+:HEAD_DIM*32]));
        end
    endgenerate
    attention_context_reduce_fp32 #(.HEAD_DIM(HEAD_DIM),.CONTEXT_PARALLEL(CONTEXT_PARALLEL)) u_context_reduce (
        .clk(clk),.rst_n(rst_n),.i_fire(lanes_done),.i_present(lane_present),
        .i_m(lane_m),.i_l(lane_l),.i_z(lane_z),
        .o_fire(context_fire),.o_present(context_present),.o_m(context_m),.o_l(context_l),.o_z(context_z));

    wire merged_fire, merged_present;
    wire [31:0] merged_m, merged_l;
    wire [HEAD_DIM*32-1:0] merged_z;
    attention_online_merge_fp32 #(.HEAD_DIM(HEAD_DIM)) u_global_merge (
        .clk(clk), .rst_n(rst_n), .i_fire(context_fire),
        .i_a_present(running_present_q), .i_a_m(running_m_q),
        .i_a_l(running_l_q), .i_a_z(running_z_q),
        .i_b_present(context_present), .i_b_m(context_m),
        .i_b_l(context_l), .i_b_z(context_z),
        .o_fire(merged_fire), .o_present(merged_present),
        .o_m(merged_m), .o_l(merged_l), .o_z(merged_z));

    integer load_slot;
    // Wide data are not reset; the control/presence bits guarantee overwrite.
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            state <= S_IDLE; context_q <= 0; loaded_q <= 0; load_lane_q <= 0;
            active_q <= 0; running_present_q <= 0;
            load_complete_q <= 0; prefetch_open_q <= 0; wave_final_q <= 0;
            o_error <= 0; o_cycle_count <= 0;
        end else begin
            if (state != S_IDLE && state != S_RESPONSE) o_cycle_count <= o_cycle_count+1;
            // Load metadata belongs to the NEXT launch. Lanes snapshot their
            // active mask at launch; context reduction snapshots old outputs
            // on lanes_done before any new K/V can affect them.
            if (state == S_WAIT && lanes_done) prefetch_open_q <= 1;
            if (kv_accept) begin
                for (load_slot=0; load_slot<KV_LOAD_PARALLEL; load_slot=load_slot+1)
                    if (loaded_q + load_slot*TILE_SIZE < context_q)
                        active_q[load_lane_q+load_slot] <= 1;
                if ({1'b0,loaded_q}+KV_LOAD_PARALLEL*TILE_SIZE >= {1'b0,context_q}) loaded_q <= context_q;
                else loaded_q <= loaded_q+KV_LOAD_PARALLEL*TILE_SIZE;
                if (load_finishes_wave) load_complete_q <= 1;
                else load_lane_q <= load_lane_q+KV_LOAD_PARALLEL;
            end
            case (state)
                S_IDLE: if (i_cmd_valid) begin
                    query_q <= i_query; context_q <= i_context_len;
                    loaded_q <= 0; load_lane_q <= 0; active_q <= 0;
                    load_complete_q <= 0; prefetch_open_q <= 0; wave_final_q <= 0;
                    running_present_q <= 0; o_cycle_count <= 0;
                    o_error <= (i_context_len == 0 || i_context_len > MAX_CONTEXT);
                    if (i_context_len == 0 || i_context_len > MAX_CONTEXT) begin
                        result_q <= 0; state <= S_RESPONSE;
                    end else state <= S_QUERY_SCALE;
                end
                S_QUERY_SCALE: begin query_scaled_q <= query_scaled; state <= S_LOAD; end
                S_LOAD: if (kv_accept && load_finishes_wave) state <= S_LAUNCH;
                S_LAUNCH: begin
                    wave_final_q <= loaded_q == context_q;
                    active_q <= 0; load_lane_q <= 0; load_complete_q <= 0;
                    prefetch_open_q <= 0; state <= S_WAIT;
                end
                S_WAIT: if (merged_fire) begin
                    running_present_q <= merged_present;
                    running_m_q <= merged_m; running_l_q <= merged_l; running_z_q <= merged_z;
                    if (wave_final_q) state <= S_INV;
                    else if (load_complete_q || (kv_accept && load_finishes_wave)) state <= S_LAUNCH;
                    else state <= S_LOAD;
                end
                S_INV: begin inverse_q <= inverse; state <= S_NORMALIZE; end
                S_NORMALIZE: begin result_q <= normalized; state <= S_RESPONSE; end
                S_RESPONSE: if (i_ready) state <= S_IDLE;
                default: state <= S_IDLE;
            endcase
        end
    end
endmodule
