`timescale 1ns/1ps
// Complete head cohort: default eight KV groups, two Q heads each. Parallel
// head groups share the same query/context schedule but distinct K/V banks.
// Atomic cohort handshakes prevent a fast group consuming a wave twice.
module attention_gqa_cohort_eval #(
    parameter integer TILE_SIZE=32,HEAD_DIM=128,CONTEXT_PARALLEL=16,
    parameter integer KV_HEADS=8,GQA_GROUP=2,QUERY_BLOCK=4,MAX_CONTEXT=1152,
    parameter [31:0] SCALE_BITS=32'h3db504f3
) (
    input wire clk,rst_n,i_cmd_valid,
    output wire o_cmd_ready,
    input wire [10:0] i_first_context,
    input wire [15:0] i_query_count,
    input wire [QUERY_BLOCK*KV_HEADS*GQA_GROUP*HEAD_DIM*32-1:0] i_queries,
    input wire i_new_kv,
    input wire [KV_HEADS*HEAD_DIM*32-1:0] i_new_keys,i_new_values,
    output wire [KV_HEADS-1:0] o_append_valid,
    input wire [KV_HEADS-1:0] i_append_ready,
    output wire [KV_HEADS*11-1:0] o_append_positions,
    output wire [KV_HEADS*HEAD_DIM*32-1:0] o_append_keys,o_append_values,
    input wire i_kv_valid,
    output wire o_kv_ready,
    output wire [10:0] o_kv_base,
    output wire [CONTEXT_PARALLEL*TILE_SIZE-1:0] o_kv_read_mask,
    input wire [KV_HEADS*CONTEXT_PARALLEL*TILE_SIZE*HEAD_DIM*32-1:0] i_keys,i_values,
    output wire o_valid,
    input wire i_ready,
    output wire [QUERY_BLOCK*KV_HEADS*GQA_GROUP*HEAD_DIM*32-1:0] o_results,
    output wire o_error,
    output wire [31:0] o_cycle_count,o_kv_wave_count
);
    wire [KV_HEADS-1:0] cmd_ready,kv_ready,valid,error;
    wire [KV_HEADS*32-1:0] cycles,waves;
    wire [KV_HEADS*11-1:0] bases;
    wire [KV_HEADS*CONTEXT_PARALLEL*TILE_SIZE-1:0] masks;
    assign o_cmd_ready=&cmd_ready;
    assign o_kv_ready=&kv_ready;
    assign o_valid=&valid;
    assign o_error=|error;
    assign o_kv_base=bases[0+:11];
    assign o_kv_read_mask=masks[0+:CONTEXT_PARALLEL*TILE_SIZE];
    assign o_cycle_count=cycles[0+:32];
    assign o_kv_wave_count=waves[0+:32];
    genvar g,q;
    generate for(g=0;g<KV_HEADS;g=g+1) begin:g_kv_group
        wire [QUERY_BLOCK*GQA_GROUP*HEAD_DIM*32-1:0] queries,results;
        for(q=0;q<QUERY_BLOCK;q=q+1) begin:g_query_order
            assign queries[q*GQA_GROUP*HEAD_DIM*32+:GQA_GROUP*HEAD_DIM*32]=
                i_queries[(q*KV_HEADS+g)*GQA_GROUP*HEAD_DIM*32+:GQA_GROUP*HEAD_DIM*32];
            assign o_results[(q*KV_HEADS+g)*GQA_GROUP*HEAD_DIM*32+:GQA_GROUP*HEAD_DIM*32]=
                results[q*GQA_GROUP*HEAD_DIM*32+:GQA_GROUP*HEAD_DIM*32];
        end
        attention_gqa_query_block_eval #(.TILE_SIZE(TILE_SIZE),.HEAD_DIM(HEAD_DIM),
            .CONTEXT_PARALLEL(CONTEXT_PARALLEL),.GQA_GROUP(GQA_GROUP),
            .QUERY_BLOCK(QUERY_BLOCK),.MAX_CONTEXT(MAX_CONTEXT),.SCALE_BITS(SCALE_BITS)) u_group(
            .clk(clk),.rst_n(rst_n),.i_cmd_valid(i_cmd_valid && o_cmd_ready),.o_cmd_ready(cmd_ready[g]),
            .i_first_context(i_first_context),.i_query_count(i_query_count),.i_queries(queries),
            .i_new_kv(i_new_kv),.i_new_key(i_new_keys[g*HEAD_DIM*32+:HEAD_DIM*32]),
            .i_new_value(i_new_values[g*HEAD_DIM*32+:HEAD_DIM*32]),
            .o_append_valid(o_append_valid[g]),.i_append_ready(i_append_ready[g]),
            .o_append_position(o_append_positions[g*11+:11]),
            .o_append_key(o_append_keys[g*HEAD_DIM*32+:HEAD_DIM*32]),
            .o_append_value(o_append_values[g*HEAD_DIM*32+:HEAD_DIM*32]),
            .i_kv_valid(i_kv_valid && o_kv_ready),.o_kv_ready(kv_ready[g]),
            .o_kv_base(bases[g*11+:11]),
            .o_kv_read_mask(masks[g*CONTEXT_PARALLEL*TILE_SIZE+:CONTEXT_PARALLEL*TILE_SIZE]),
            .i_keys(i_keys[g*CONTEXT_PARALLEL*TILE_SIZE*HEAD_DIM*32+:CONTEXT_PARALLEL*TILE_SIZE*HEAD_DIM*32]),
            .i_values(i_values[g*CONTEXT_PARALLEL*TILE_SIZE*HEAD_DIM*32+:CONTEXT_PARALLEL*TILE_SIZE*HEAD_DIM*32]),
            .o_valid(valid[g]),.i_ready(i_ready && o_valid),.o_results(results),.o_error(error[g]),
            .o_cycle_count(cycles[g*32+:32]),.o_kv_wave_count(waves[g*32+:32]));
    end endgenerate
endmodule
