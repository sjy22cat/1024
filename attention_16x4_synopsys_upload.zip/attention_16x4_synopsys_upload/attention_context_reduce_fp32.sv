`timescale 1ns/1ps

// One common maximum, parallel rescaling, then balanced sum trees.
// Latency: 2*clog2(CONTEXT_PARALLEL)+3 registered stages (11 for 16).
// i_fire is a pulse; the next transaction must wait for o_fire. Inputs are
// snapshotted on i_fire, so the context lanes may immediately load new K/V.
module attention_context_reduce_fp32 #(
    parameter integer HEAD_DIM=128,
    parameter integer CONTEXT_PARALLEL=16
)(
    input wire clk, rst_n, i_fire,
    input wire [CONTEXT_PARALLEL-1:0] i_present,
    input wire [CONTEXT_PARALLEL*32-1:0] i_m, i_l,
    input wire [CONTEXT_PARALLEL*HEAD_DIM*32-1:0] i_z,
    output reg o_fire,
    output wire o_present,
    output wire [31:0] o_m, o_l,
    output wire [HEAD_DIM*32-1:0] o_z
);
    localparam integer LEVELS=$clog2(CONTEXT_PARALLEL);
    localparam integer IDLE=0, MAXIMUM=1, DIFFERENCE=2, EXPONENT=3, PRODUCT=4, SUM=5;
    reg [2:0] state;
    integer level_q;
    reg [CONTEXT_PARALLEL-1:0] present_q;
    reg [31:0] m_q[0:CONTEXT_PARALLEL-1];
    reg [31:0] operand_q[0:CONTEXT_PARALLEL-1][0:HEAD_DIM];
    reg [31:0] max_q[1:CONTEXT_PARALLEL-1];
    reg [31:0] diff_q[0:CONTEXT_PARALLEL-1], alpha_q[0:CONTEXT_PARALLEL-1];
    reg [31:0] sum_q[1:2*CONTEXT_PARALLEL-1][0:HEAD_DIM];
    wire [31:0] maximum[1:2*CONTEXT_PARALLEL-1];
    wire [31:0] difference[0:CONTEXT_PARALLEL-1], exponent[0:CONTEXT_PARALLEL-1];
    wire [31:0] product[0:CONTEXT_PARALLEL-1][0:HEAD_DIM];
    wire [31:0] addition[1:CONTEXT_PARALLEL-1][0:HEAD_DIM];
    function automatic [31:0] fp_max(input [31:0] a,b);
        if(a[31]!=b[31]) fp_max=a[31]?b:a;
        else if(a[31]) fp_max=(a[30:0]<b[30:0])?a:b;
        else fp_max=(a[30:0]>b[30:0])?a:b;
    endfunction
    initial if(CONTEXT_PARALLEL<2 || (CONTEXT_PARALLEL & (CONTEXT_PARALLEL-1))!=0)
        $fatal(1,"context reduction requires a power-of-two lane count >= 2");
    assign o_present=|present_q;
    assign o_m=o_present?max_q[1]:32'b0;
    assign o_l=sum_q[1][HEAD_DIM];
    genvar c,d,n;
    generate
        for(d=0;d<HEAD_DIM;d=d+1) begin:g_output
            assign o_z[d*32+:32]=sum_q[1][d];
        end
        for(c=0;c<CONTEXT_PARALLEL;c=c+1) begin:g_lane
            assign maximum[CONTEXT_PARALLEL+c]=i_present[c]?i_m[c*32+:32]:32'hff800000;
            wire [7:0] sd,se;
            DW_fp_addsub #(.sig_width(23),.exp_width(8),.ieee_compliance(0)) u_diff(
                .a(present_q[c]?m_q[c]:32'b0),.b(present_q[c]?max_q[1]:32'b0),
                .rnd(3'b000),.op(1'b1),.z(difference[c]),.status(sd));
            DW_fp_exp #(.sig_width(23),.exp_width(8),.ieee_compliance(0),.arch(2)) u_exp(
                .a(diff_q[c]),.z(exponent[c]),.status(se));
            for(d=0;d<=HEAD_DIM;d=d+1) begin:g_scale
                wire [7:0] status;
                DW_fp_mult #(.sig_width(23),.exp_width(8),.ieee_compliance(0)) u_mul(
                    .a(operand_q[c][d]),.b(alpha_q[c]),.rnd(3'b000),
                    .z(product[c][d]),.status(status));
            end
        end
        for(n=1;n<CONTEXT_PARALLEL;n=n+1) begin:g_tree
            if(n>=CONTEXT_PARALLEL/2) begin:g_bottom
                assign maximum[n]=fp_max(maximum[2*n],maximum[2*n+1]);
            end else begin:g_upper
                assign maximum[n]=fp_max(max_q[2*n],max_q[2*n+1]);
            end
            for(d=0;d<=HEAD_DIM;d=d+1) begin:g_sum
                wire [7:0] status;
                DW_fp_addsub #(.sig_width(23),.exp_width(8),.ieee_compliance(0)) u_add(
                    .a(sum_q[2*n][d]),.b(sum_q[2*n+1][d]),.rnd(3'b000),.op(1'b0),
                    .z(addition[n][d]),.status(status));
            end
        end
    endgenerate
    integer ic,id,inode;
    always @(posedge clk or negedge rst_n) begin
        if(!rst_n) begin state<=IDLE;level_q<=0;o_fire<=0;present_q<=0;end
        else begin
            o_fire<=0;
            case(state)
                IDLE:if(i_fire) begin
                    present_q<=i_present;
                    for(ic=0;ic<CONTEXT_PARALLEL;ic=ic+1) begin
                        m_q[ic]<=i_present[ic]?i_m[ic*32+:32]:32'b0;
                        for(id=0;id<HEAD_DIM;id=id+1)
                            operand_q[ic][id]<=i_present[ic]?i_z[(ic*HEAD_DIM+id)*32+:32]:32'b0;
                        operand_q[ic][HEAD_DIM]<=i_present[ic]?i_l[ic*32+:32]:32'b0;
                    end
                    for(inode=CONTEXT_PARALLEL/2;inode<CONTEXT_PARALLEL;inode=inode+1)
                        max_q[inode]<=maximum[inode];
                    level_q<=2;
                    state<=(LEVELS==1)?DIFFERENCE:MAXIMUM;
                end
                MAXIMUM:begin
                    for(inode=1;inode<CONTEXT_PARALLEL;inode=inode+1)
                        if(inode>=(CONTEXT_PARALLEL>>level_q) && inode<(CONTEXT_PARALLEL>>(level_q-1)))
                            max_q[inode]<=maximum[inode];
                    if(level_q==LEVELS) state<=DIFFERENCE;else level_q<=level_q+1;
                end
                DIFFERENCE:begin
                    for(ic=0;ic<CONTEXT_PARALLEL;ic=ic+1) diff_q[ic]<=difference[ic];
                    state<=EXPONENT;
                end
                EXPONENT:begin
                    for(ic=0;ic<CONTEXT_PARALLEL;ic=ic+1) alpha_q[ic]<=present_q[ic]?exponent[ic]:32'b0;
                    state<=PRODUCT;
                end
                PRODUCT:begin
                    for(ic=0;ic<CONTEXT_PARALLEL;ic=ic+1)
                        for(id=0;id<=HEAD_DIM;id=id+1) sum_q[CONTEXT_PARALLEL+ic][id]<=product[ic][id];
                    level_q<=1;state<=SUM;
                end
                SUM:begin
                    for(inode=1;inode<CONTEXT_PARALLEL;inode=inode+1)
                        if(inode>=(CONTEXT_PARALLEL>>level_q) && inode<(CONTEXT_PARALLEL>>(level_q-1)))
                            for(id=0;id<=HEAD_DIM;id=id+1) sum_q[inode][id]<=addition[inode][id];
                    if(level_q==LEVELS) begin o_fire<=1;state<=IDLE;end
                    else level_q<=level_q+1;
                end
                default:state<=IDLE;
            endcase
        end
    end
endmodule
