`timescale 1ns/1ps
module tb_attention_gqa_query_block #(
    parameter integer TILE_SIZE=2,
    parameter integer C=2,
    parameter integer D=4*TILE_SIZE,
    parameter integer QB=4,
    parameter integer MAX_N=3*C*TILE_SIZE,
    parameter [31:0] SCALE=32'h3db504f3
);
    import nonmac_test_math::*;
    localparam integer G=2,W=C*TILE_SIZE;
    reg clk=0,rst_n=0,cmd=0,kv_valid=0,ready=0,append_ready=0,new_kv=0;
    always #0.5 clk=~clk;
    reg [10:0] first=1;
    reg [15:0] count=1;
    reg [QB*G*D*32-1:0] queries=0;
    reg [D*32-1:0] new_key=0,new_value=0;
    reg [W*D*32-1:0] keys=0,values=0;
    wire cmd_ready,kv_ready,valid,error,append_valid;
    wire [10:0] base,append_pos;
    wire [W-1:0] mask;
    wire [D*32-1:0] append_key,append_value;
    wire [QB*G*D*32-1:0] results;
    wire [31:0] cycles,waves;
    integer clocks=0;
    always @(posedge clk) clocks=clocks+1;
    attention_gqa_query_block_eval #(.TILE_SIZE(TILE_SIZE),.HEAD_DIM(D),
        .CONTEXT_PARALLEL(C),.QUERY_BLOCK(QB),.MAX_CONTEXT(MAX_N),.SCALE_BITS(SCALE)) dut(
        .clk(clk),.rst_n(rst_n),.i_cmd_valid(cmd),.o_cmd_ready(cmd_ready),
        .i_first_context(first),.i_query_count(count),.i_queries(queries),
        .i_new_kv(new_kv),.i_new_key(new_key),.i_new_value(new_value),
        .o_append_valid(append_valid),.i_append_ready(append_ready),
        .o_append_position(append_pos),.o_append_key(append_key),.o_append_value(append_value),
        .i_kv_valid(kv_valid),.o_kv_ready(kv_ready),.o_kv_base(base),.o_kv_read_mask(mask),
        .i_keys(keys),.i_values(values),.o_valid(valid),.i_ready(ready),.o_results(results),
        .o_error(error),.o_cycle_count(cycles),.o_kv_wave_count(waves));
    real qr[0:QB-1][0:G-1][0:D-1];
    real kr[0:MAX_N-1][0:D-1],vr[0:MAX_N-1][0:D-1];
    real scores[0:MAX_N-1];
    integer handshakes,append_count,read_tokens;
    always @(posedge clk) if(rst_n) begin
        if(kv_valid && kv_ready) handshakes=handshakes+1;
        if(append_valid && append_ready) append_count=append_count+1;
    end
    task automatic run_case(input integer start_n,nq,bypass,stalls);
        integer t,d,q,h,j,n,steps,begin_clock,expect_cycles,active,skip,w;
        real score,m,den,expected,actual,err,maxerr;
        reg [QB*G*D*32-1:0] held;
        begin
            while(!cmd_ready) @(negedge clk);
            n=start_n+nq-1;
            for(q=0;q<QB;q=q+1) for(h=0;h<G;h=h+1) for(d=0;d<D;d=d+1) begin
                qr[q][h][d]=((q*11+h*7+d*3)%19-9)/32.0;
                queries[((q*G+h)*D+d)*32+:32]=real_fp(qr[q][h][d]);
            end
            for(t=0;t<n;t=t+1) for(d=0;d<D;d=d+1) begin
                kr[t][d]=((t*7+d*3)%23-11)/16.0;
                vr[t][d]=((t*13+d*5)%29-14)/16.0;
            end
            for(d=0;d<D;d=d+1) begin
                new_key[d*32+:32]=real_fp(kr[n-1][d]);
                new_value[d*32+:32]=real_fp(vr[n-1][d]);
            end
            first=start_n;count=nq;new_kv=bypass;cmd=1;
            handshakes=0;append_count=0;read_tokens=0;
            @(negedge clk);cmd=0;begin_clock=clocks;
            // Hold FeRAM append backpressured through the entire compute.
            append_ready=0;
            for(w=0;w<(n+W-1)/W;w=w+1) begin
                while(!kv_ready) @(negedge clk);
                repeat(stalls) @(negedge clk);
                if(base!=w*W) $fatal(1,"wave address mismatch");
                for(t=0;t<W;t=t+1) begin
                    if(mask[t]) read_tokens=read_tokens+1;
                    if(mask[t] !== (w*W+t<n && !(bypass && w*W+t==n-1)))
                        $fatal(1,"padding/new-token read mask mismatch");
                    for(d=0;d<D;d=d+1) begin
                        keys[(t*D+d)*32+:32]=mask[t] ? real_fp(kr[w*W+t][d]) : 32'h7fc00000;
                        values[(t*D+d)*32+:32]=mask[t] ? real_fp(vr[w*W+t][d]) : 32'h7fc00000;
                    end
                end
                kv_valid=1;@(negedge clk);kv_valid=0;keys='x;values='x;
            end
            while(!valid) @(negedge clk);
            active=0;skip=0;
            for(w=0;w<(n+W-1)/W;w=w+1) for(q=0;q<nq;q=q+1)
                if(start_n+q>w*W) active=active+1; else skip=skip+1;
            expect_cycles=2+(3*$clog2(TILE_SIZE)+2*$clog2(C)+16)*active+2*nq+skip+stalls;
            if(stalls==0 && (cycles!=expect_cycles || clocks-begin_clock!=cycles))
                $fatal(1,"cycles got=%0d measured=%0d expected=%0d",cycles,clocks-begin_clock,expect_cycles);
            if(error || waves!=handshakes || waves!=(n+W-1)/W || read_tokens!=n-bypass)
                $fatal(1,"traffic/query-block error");
            maxerr=0;
            for(q=0;q<nq;q=q+1) for(h=0;h<G;h=h+1) begin
                m=-1.0e100;
                for(t=0;t<start_n+q;t=t+1) begin
                    score=0;
                    for(d=0;d<D;d=d+1) score=score+qr[q][h][d]*fp_real(SCALE)*kr[t][d];
                    scores[t]=score;if(score>m) m=score;
                end
                den=0;for(t=0;t<start_n+q;t=t+1) den=den+$exp(scores[t]-m);
                for(d=0;d<D;d=d+1) begin
                    expected=0;
                    for(t=0;t<start_n+q;t=t+1) expected=expected+$exp(scores[t]-m)*vr[t][d]/den;
                    if(results[((q*G+h)*D+d)*32+23+:8]==8'hff ||
                       (^results[((q*G+h)*D+d)*32+:32])===1'bx) $fatal(1,"nonfinite result");
                    actual=fp_real(results[((q*G+h)*D+d)*32+:32]);
                    err=actual-expected;if(err<0) err=-err;
                    if(err>maxerr) maxerr=err;
                    if(err>1e-4+1e-3*$abs(expected))
                        $fatal(1,"causal/GQA numeric q=%0d h=%0d d=%0d got=%g ref=%g",q,h,d,actual,expected);
                end
            end
            held=results;
            repeat(3) begin
                @(negedge clk);
                if(!valid || results!==held || cmd_ready) $fatal(1,"output hold failed");
                if(bypass && (!append_valid || append_key!==new_key || append_value!==new_value || append_pos!=n-1))
                    $fatal(1,"append corrupted/stalled compute");
            end
            ready=1;@(negedge clk);ready=0;
            if(bypass && cmd_ready) $fatal(1,"overwrote uncommitted append");
            append_ready=1;@(negedge clk);append_ready=0;
            if(append_count!=bypass) $fatal(1,"append count mismatch");
            $display("PASS GQA/query-block first=%0d queries=%0d bypass=%0d stalls=%0d cycles=%0d waves=%0d maxerr=%g",
                start_n,nq,bypass,stalls,cycles,waves,maxerr);
        end
    endtask
    task automatic reject(input integer n,nq,bypass);
        begin
            while(!cmd_ready) @(negedge clk);
            first=n;count=nq;new_kv=bypass;cmd=1;@(negedge clk);cmd=0;
            if(!valid || !error || cycles!=0 || append_valid || kv_ready) $fatal(1,"invalid command accepted");
            ready=1;@(negedge clk);ready=0;
        end
    endtask
    initial begin
        repeat(3) @(negedge clk);rst_n=1;
        run_case(1,1,1,0);
        run_case(1,QB,0,0);
        run_case(W-1,QB,0,0); // query block straddles a context-wave boundary
        run_case(MAX_N-QB+1,QB,0,0);
        run_case(MAX_N,1,1,0);
        run_case(MAX_N,1,1,2);
        reject(0,1,0);reject(1,0,0);reject(MAX_N,2,0);reject(1,2,1);
        // Reset cancels both an unfinished command and an uncommitted append.
        first=MAX_N;count=1;new_kv=1;cmd=1;@(negedge clk);cmd=0;
        rst_n=0;repeat(2) @(negedge clk);rst_n=1;@(negedge clk);
        if(append_valid || valid || !cmd_ready) $fatal(1,"reset left stale work");
        run_case(1,1,0,0);
        $display("PASS shared KV, causal state retention, newest-token bypass, append/output backpressure, reset/errors");
        $finish;
    end
    initial begin repeat(200000) @(negedge clk);$fatal(1,"timeout");end
endmodule
