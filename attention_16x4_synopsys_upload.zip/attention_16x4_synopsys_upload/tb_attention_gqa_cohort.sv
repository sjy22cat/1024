`timescale 1ns/1ps
module tb_attention_gqa_cohort;
    import nonmac_test_math::*;
    localparam D=8,C=2,T=2,W=4,G=2,KH=2,QB=2;
    reg clk=0,rst_n=0,cmd=0,kv_valid=0,ready=0,new_kv=0;
    always #0.5 clk=~clk;
    reg [KH-1:0] append_ready=0;
    reg [10:0] first=3;
    reg [15:0] count=2;
    reg [QB*KH*G*D*32-1:0] queries=0;
    reg [KH*D*32-1:0] new_keys=0,new_values=0;
    reg [KH*W*D*32-1:0] keys=0,values=0;
    wire cmd_ready,kv_ready,valid,error;
    wire [KH-1:0] append_valid;
    wire [10:0] base;
    wire [W-1:0] mask;
    wire [KH*11-1:0] append_pos;
    wire [KH*D*32-1:0] append_keys,append_values;
    wire [QB*KH*G*D*32-1:0] results;
    wire [31:0] cycles,waves;
    attention_gqa_cohort_eval #(.TILE_SIZE(T),.HEAD_DIM(D),.CONTEXT_PARALLEL(C),
        .KV_HEADS(KH),.QUERY_BLOCK(QB),.MAX_CONTEXT(12)) dut(
        .clk(clk),.rst_n(rst_n),.i_cmd_valid(cmd),.o_cmd_ready(cmd_ready),
        .i_first_context(first),.i_query_count(count),.i_queries(queries),.i_new_kv(new_kv),
        .i_new_keys(new_keys),.i_new_values(new_values),.o_append_valid(append_valid),
        .i_append_ready(append_ready),.o_append_positions(append_pos),
        .o_append_keys(append_keys),.o_append_values(append_values),
        .i_kv_valid(kv_valid),.o_kv_ready(kv_ready),.o_kv_base(base),.o_kv_read_mask(mask),
        .i_keys(keys),.i_values(values),.o_valid(valid),.i_ready(ready),.o_results(results),
        .o_error(error),.o_cycle_count(cycles),.o_kv_wave_count(waves));
    integer g,t,d,q,h,w;
    real expected,actual;
    task automatic run(input integer n,nq,bypass);
        begin
            while(!cmd_ready) @(negedge clk);
            first=n;count=nq;new_kv=bypass;
            for(g=0;g<KH;g=g+1) for(d=0;d<D;d=d+1)
                new_values[(g*D+d)*32+:32]=real_fp(1000.0+g*100+d/8.0);
            cmd=1;@(negedge clk);cmd=0;
            for(w=0;w<(n+nq-2+W)/W;w=w+1) begin
                while(!kv_ready) @(negedge clk);
                for(g=0;g<KH;g=g+1) for(t=0;t<W;t=t+1) for(d=0;d<D;d=d+1) begin
                    keys[((g*W+t)*D+d)*32+:32]=mask[t] ? 0 : 32'h7fc00000;
                    values[((g*W+t)*D+d)*32+:32]=mask[t] ?
                        real_fp(base+t+g*100+d/8.0) : 32'h7fc00000;
                end
                kv_valid=1;@(negedge clk);kv_valid=0;
                if(bypass && w==0) begin
                    append_ready=1;@(negedge clk);append_ready=0;
                    if(append_valid!==2'b10) $fatal(1,"independent append acknowledgment failed");
                end
            end
            while(!valid) @(negedge clk);
            for(q=0;q<nq;q=q+1) for(g=0;g<KH;g=g+1) for(h=0;h<G;h=h+1) for(d=0;d<D;d=d+1) begin
                expected=bypass ? ((n-2.0)*(n-1.0)/2.0+1000.0)/n : (n+q-1.0)/2.0;
                expected=expected+g*100+d/8.0;
                actual=fp_real(results[(((q*KH+g)*G+h)*D+d)*32+:32]);
                if($abs(actual-expected)>1e-4 || error) $fatal(1,"cohort KV/query ordering mismatch");
            end
            ready=1;@(negedge clk);ready=0;
            if(bypass) begin
                if(cmd_ready) $fatal(1,"cohort accepted command before slow append committed");
                append_ready=2'b10;@(negedge clk);append_ready=0;
            end
            $display("PASS cohort distinct KV heads, packed query mapping, independent append stalls n=%0d count=%0d cycles=%0d",n,nq,cycles);
        end
    endtask
    initial begin
        repeat(3) @(negedge clk);rst_n=1;
        run(3,2,0);run(5,1,1);run(1,1,0);
        $finish;
    end
    initial begin repeat(10000) @(negedge clk);$fatal(1,"timeout");end
endmodule
