`timescale 1ns/1ps

// One context row: TILE_SIZE tokens x four TILE_SIZE-wide dimension blocks.
// QK and PV reuse the same four multiplier/reduction planes in distinct
// phases. The score includes all four dimension blocks before Softmax.
// Reductions allocate only real tree nodes (2*TILE_SIZE-1 per output).
module attention_context_4dim_lane #(
    parameter integer TILE_SIZE = 32,
    parameter integer HEAD_DIM = 128,
    parameter integer EXTERNAL_KV = 0
) (
    input wire clk, rst_n,
    input wire i_load,
    input wire [TILE_SIZE-1:0] i_token_mask,
    input wire [TILE_SIZE*HEAD_DIM*32-1:0] i_key, i_value,
    input wire i_start, i_active,
    input wire [HEAD_DIM*32-1:0] i_query_scaled,
    output wire o_done,
    output wire o_present,
    output wire [31:0] o_m, o_l,
    output wire [HEAD_DIM*32-1:0] o_z
);
    localparam integer LEVELS = $clog2(TILE_SIZE);
    localparam integer NODES = 2*TILE_SIZE;
    localparam integer S_IDLE=0, S_QK_MUL=1, S_QK_TREE=2,
        S_DIM_1=3, S_DIM_2=4, S_MAX=5, S_DIFF=6, S_EXP=7,
        S_PV_MUL=8, S_PV_TREE=9, S_DONE=10;
    reg [3:0] state;
    integer level_q;
    reg active_q;
    reg [TILE_SIZE-1:0] token_mask_q, loaded_mask_q;
    wire [TILE_SIZE*HEAD_DIM*32-1:0] key_q, value_q;
    generate if (EXTERNAL_KV) begin : g_external_kv
        // A GQA group owns one immutable wave bank shared by its Q heads.
        assign key_q = i_key;
        assign value_q = i_value;
    end else begin : g_local_kv
        reg [TILE_SIZE*HEAD_DIM*32-1:0] key_bank, value_bank;
        always @(posedge clk) if (rst_n && i_load) begin
            key_bank <= i_key; value_bank <= i_value;
        end
        assign key_q = key_bank;
        assign value_q = value_bank;
    end endgenerate
    wire [HEAD_DIM*32-1:0] mac_z;
    wire [TILE_SIZE*32-1:0] score_vec;
    wire [TILE_SIZE*32-1:0] beta_vec;
    attention_qk_pv_mac_fp32 #(.TILE_SIZE(TILE_SIZE), .HEAD_DIM(HEAD_DIM)) u_mac (
        .clk(clk), .rst_n(rst_n), .i_active(active_q), .i_mask(token_mask_q),
        .i_mul(state==S_QK_MUL || state==S_PV_MUL), .i_qk(state==S_QK_MUL),
        .i_tree(state==S_QK_TREE || state==S_PV_TREE), .i_level(level_q),
        .i_dim1(state==S_DIM_1), .i_dim2(state==S_DIM_2),
        .i_query(i_query_scaled), .i_key(key_q), .i_value(value_q), .i_beta(beta_vec),
        .o_score(score_vec), .o_z(mac_z));
    assign o_z = o_present ? mac_z : {HEAD_DIM*32{1'b0}};
    reg [31:0] max_q [1:NODES-1];
    reg [31:0] sum_q [1:NODES-1];
    reg [31:0] diff_q [0:TILE_SIZE-1];
    reg [31:0] beta_q [0:TILE_SIZE-1];

    function automatic [31:0] fp_max(input [31:0] a, b);
        if (a[31] != b[31]) fp_max = a[31] ? b : a;
        else if (a[31]) fp_max = (a[30:0] < b[30:0]) ? a : b;
        else fp_max = (a[30:0] > b[30:0]) ? a : b;
    endfunction

    initial begin
        if (TILE_SIZE < 2 || TILE_SIZE > 32 || (TILE_SIZE & (TILE_SIZE-1)) != 0 ||
            HEAD_DIM != 4*TILE_SIZE) $fatal(1, "lane requires HEAD_DIM=4*TILE_SIZE");
    end
    assign o_done = (state == S_DONE);
    assign o_present = active_q && (|token_mask_q);
    // Empty states use finite zero; merge presence bits carry emptiness.
    assign o_m = o_present ? max_q[1] : 32'b0;
    assign o_l = o_present ? sum_q[1] : 32'b0;

    wire [31:0] diff [0:TILE_SIZE-1], beta [0:TILE_SIZE-1];
    wire [31:0] max_node [1:NODES-1], sum_add [1:TILE_SIZE-1];
    genvar p, n;
    generate
        for (p=0; p<TILE_SIZE; p=p+1) begin : g_score
            wire [7:0] sd, se;
            wire [31:0] score = score_vec[p*32+:32];
            assign beta_vec[p*32+:32] = beta_q[p];
            assign max_node[TILE_SIZE+p] = active_q && token_mask_q[p] ? score : 32'hff800000;
            DW_fp_addsub #(.sig_width(23), .exp_width(8), .ieee_compliance(0)) u_diff (
                .a(active_q && token_mask_q[p] ? score : 32'b0),
                .b(o_present ? max_q[1] : 32'b0), .rnd(3'b000), .op(1'b1),
                .z(diff[p]), .status(sd));
            DW_fp_exp #(.sig_width(23), .exp_width(8), .ieee_compliance(0), .arch(2)) u_exp (
                .a(diff_q[p]), .z(beta[p]), .status(se));
        end
        for (n=1; n<TILE_SIZE; n=n+1) begin : g_softmax_tree
            // Bottom max level reads score registers directly; higher levels
            // read the previous registered level. One comparator per stage.
            if (n >= TILE_SIZE/2) begin : g_bottom
                assign max_node[n] = fp_max(max_node[2*n], max_node[2*n+1]);
            end else begin : g_upper
                assign max_node[n] = fp_max(max_q[2*n], max_q[2*n+1]);
            end
            wire [7:0] status;
            DW_fp_addsub #(.sig_width(23), .exp_width(8), .ieee_compliance(0)) u_sum (
                .a(sum_q[2*n]), .b(sum_q[2*n+1]), .rnd(3'b000), .op(1'b0),
                .z(sum_add[n]), .status(status));
        end
    endgenerate

    // No reset fanout on K/V or tree datapath banks. Masks and state prevent
    // reading any bank before it has been written for the current wave.
    always @(posedge clk) if (rst_n && i_load) begin
        loaded_mask_q <= i_token_mask;
    end
    integer ip, inode;
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin state <= S_IDLE; level_q <= 0; active_q <= 0; end
        else case (state)
            S_IDLE: if (i_start) begin
                active_q <= i_active; token_mask_q <= EXTERNAL_KV ? i_token_mask : loaded_mask_q; state <= S_QK_MUL;
            end
            S_QK_MUL, S_PV_MUL: begin
                if (state == S_PV_MUL)
                    for (ip=0; ip<TILE_SIZE; ip=ip+1) sum_q[TILE_SIZE+ip] <= beta_q[ip];
                level_q <= 1;
                state <= (state == S_QK_MUL) ? S_QK_TREE : S_PV_TREE;
            end
            S_QK_TREE, S_PV_TREE: begin
                for (inode=1; inode<TILE_SIZE; inode=inode+1)
                    if (inode >= (TILE_SIZE >> level_q) && inode < (TILE_SIZE >> (level_q-1))) begin
                        if (state == S_PV_TREE) sum_q[inode] <= sum_add[inode];
                    end
                if (level_q == LEVELS) state <= (state == S_QK_TREE) ? S_DIM_1 : S_DONE;
                else level_q <= level_q+1;
            end
            S_DIM_1: begin
                state <= S_DIM_2;
            end
            S_DIM_2: begin
                level_q <= 1; state <= S_MAX;
            end
            S_MAX: begin
                for (inode=1; inode<TILE_SIZE; inode=inode+1)
                    if (inode >= (TILE_SIZE >> level_q) && inode < (TILE_SIZE >> (level_q-1)))
                        max_q[inode] <= max_node[inode];
                if (level_q == LEVELS) state <= S_DIFF;
                else level_q <= level_q+1;
            end
            S_DIFF: begin
                for (ip=0; ip<TILE_SIZE; ip=ip+1)
                    diff_q[ip] <= active_q && token_mask_q[ip] ? diff[ip] : 32'b0;
                state <= S_EXP;
            end
            S_EXP: begin
                for (ip=0; ip<TILE_SIZE; ip=ip+1)
                    beta_q[ip] <= active_q && token_mask_q[ip] ? beta[ip] : 32'b0;
                state <= S_PV_MUL;
            end
            S_DONE: state <= S_IDLE;
            default: state <= S_IDLE;
        endcase
    end
endmodule
