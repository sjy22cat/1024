source synopsys/common.tcl
set_app_var target_library $target_db
set_app_var synthetic_library [list dw_foundation.sldb]
set_app_var link_library [concat [list *] $target_db $extra_link_db [list dw_foundation.sldb]]
define_design_lib WORK -path [file join $run_dir work]
set fd [open sources.f r]
set rtl [split [string trim [read $fd]] \n]
close $fd
analyze -format sverilog $rtl
elaborate attention_head_16ctx_4dim_eval
current_design attention_head_16ctx_4dim_eval
link
uniquify
save_report dc_units.rpt {report_units}
save_report dc_check_before.rpt {check_design}
source synopsys/constraints.tcl
# Preserve a real MAC ownership boundary while allowing technology mapping
# INSIDE it. Do NOT set_dont_touch on the unmapped u_mac modules.
set hier [get_cells -hierarchical -filter {is_hierarchical == true}]
set_ungroup $hier false
set_boundary_optimization $hier false
compile_ultra -no_autoungroup
set macs [get_cells -hierarchical -filter {is_hierarchical == true && full_name =~ */u_mac}]
if {[sizeof_collection $macs]!=16} {error "Expected 16 preserved u_mac instances"}
save_report dc_check_after.rpt {check_design}
save_report dc_area.rpt {report_area -hierarchy}
save_report dc_resources.rpt {report_resources -hierarchy}
save_report dc_qor.rpt {report_qor}
save_report dc_constraints.rpt {report_constraint -all_violators}
save_report dc_timing.rpt {report_timing -delay_type max -max_paths 20 -nets -transition_time -capacitance}
write -format verilog -hierarchy -output [file join $run_dir mapped.v]
write -format ddc -hierarchy -output [file join $run_dir mapped.ddc]
write_sdc [file join $run_dir mapped.sdc]
exit
