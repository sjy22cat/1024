source synopsys/common.tcl
set_app_var link_path [concat [list *] $target_db $extra_link_db]
if {$::env(ATTN_STAGE)=="power"} {
    set_app_var power_enable_analysis true
    set_app_var power_analysis_mode averaged
}
read_verilog [file join $run_dir mapped.v]
current_design attention_head_16ctx_4dim_eval
link_design attention_head_16ctx_4dim_eval
source synopsys/constraints.tcl
update_timing
save_report pt_units.rpt {report_units}
save_report pt_check.rpt {check_timing -verbose}
save_report pt_coverage.rpt {report_analysis_coverage}
save_report pt_constraints.rpt {report_constraint -all_violators}
save_report pt_setup.rpt {report_timing -delay_type max -max_paths 30 -nets -transition_time -capacitance -input_pins}
save_report pt_hold.rpt {report_timing -delay_type min -max_paths 30 -nets -transition_time -capacitance -input_pins}
set macs [get_cells -hierarchical -filter {is_hierarchical == true && full_name =~ */u_mac}]
if {[sizeof_collection $macs]!=16} {error "MAC partition missing/flattened"}
set fd [open [file join $run_dir mac_instances.txt] w]
foreach_in_collection m $macs {puts $fd [get_object_name $m]}
close $fd
save_report pt_area.rpt {report_design}
# Hierarchical area aggregation must be checked against library leaf-cell sums.
# Preserve both raw values and source reports; do not infer area from time share.
set af [open [file join $run_dir area_attributes.tsv] w]
puts $af "scope\tarea_library_units"
if {![catch {get_attribute -quiet [current_design] area} a]} {puts $af "TOTAL\t$a"}
foreach_in_collection m $macs {
    if {![catch {get_attribute -quiet $m area} a]} {puts $af "[get_object_name $m]\t$a"}
}
close $af
if {$::env(ATTN_STAGE)=="power"} {
    # read_vcd -time units vary from tool/report units; site must explicitly
    # confirm them from this installed command's man page and VCD timescale.
    set ns_per_tool_time $read_vcd_time_unit_ns
    read_vcd -strip_path tb_attention_head_16ctx_4dim/dut \
        -time [list [expr {$window_start_ns/$ns_per_tool_time}] [expr {$window_end_ns/$ns_per_tool_time}]] $activity_vcd
    update_power
    set tag $power_tag
    save_report ${tag}_power_total.rpt {report_power -verbose}
    save_report ${tag}_power_hierarchy.rpt {report_power -hierarchy -levels 8}
    save_report ${tag}_activity.rpt {report_switching_activity}
    save_report ${tag}_power_check.rpt {check_power -verbose}
    # PT attributes are retained as RAW, version-dependent readings. Validate
    # against report_power and report_units before completing measurement.json.
    set pf [open [file join $run_dir ${tag}_power_attributes.tsv] w]
    puts $pf "scope\tinternal_power\tswitching_power\tleakage_power\ttotal_power"
    set objects [list [list TOTAL [current_design]]]
    foreach_in_collection m $macs {lappend objects [list [get_object_name $m] $m]}
    foreach pair $objects {
        lassign $pair label obj
        set vals [list $label]
        foreach attr {internal_power switching_power leakage_power total_power} {
            if {[catch {get_attribute -quiet $obj $attr} v] || $v==""} {set v UNAVAILABLE}
            lappend vals $v
        }
        puts $pf [join $vals \t]
    }
    close $pf
    # Preserve per-MAC reports (same run/window), including reweight multipliers
    # OUTSIDE u_mac in the residual, even though they are also FP multipliers.
    set idx 0
    foreach_in_collection m $macs {
        save_report ${tag}_mac_${idx}.rpt [list report_power -cell_power -verbose $m]
        incr idx
    }
}
exit
