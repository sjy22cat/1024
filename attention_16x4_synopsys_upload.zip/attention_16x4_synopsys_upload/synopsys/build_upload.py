#!/usr/bin/env python3
"""Allowlisted, self-contained expanded+ZIP Synopsys deliverable."""
from datetime import datetime
import hashlib
import json
from pathlib import Path
import shutil
import tempfile
import zipfile

ROOT=Path(__file__).resolve().parents[1]
OUTPUT=ROOT/"upload"
NAME="attention_16x4_synopsys_upload"
SYNOPSYS=("site.example.json","run_flow.py","dc.tcl","pt.tcl","common.tcl","constraints.tcl",
          "MEASUREMENT_CONTRACT.md","PROMPT_SYNOPSYS.md","measurement.template.json",
          "collect_candidate.py","subtract_mac.py","test_subtract_mac.py","build_upload.py")
VERIFY='''from pathlib import Path
import hashlib,json
r=Path(__file__).resolve().parent
m=json.loads((r/"UPLOAD_MANIFEST.json").read_text(encoding="utf-8"))
bad=[n for n,h in m["files"].items() if not (r/n).is_file() or hashlib.sha256((r/n).read_bytes()).hexdigest()!=h]
if bad: raise SystemExit("Missing/changed files: "+str(bad))
sources=(r/"sources.f").read_text(encoding="utf-8").splitlines()
assert len(sources)==7 and all((r/n).is_file() for n in sources)
assert not (r/"verification/nonmac_test_dw.sv").exists()
print("PASS upload SHA256:",len(m["files"]),"files; 7 RTL sources; no synthetic DW models")
'''

def main():
    OUTPUT.mkdir(exist_ok=True)
    sources=(ROOT/"sources.f").read_text(encoding="utf-8").splitlines()
    allow=["README.md","sources.f"]+sources+[
        "tb_attention_head_16ctx_4dim.sv","tb_attention_gqa_query_block.sv","tb_attention_gqa_cohort.sv",
        "verification/nonmac_tb_math.sv"]+["synopsys/"+s for s in SYNOPSYS]
    if (ROOT/"verification/local_validation.json").is_file(): allow.append("verification/local_validation.json")
    if (ROOT/"verification/refactor_equivalence.json").is_file(): allow.append("verification/refactor_equivalence.json")
    assert len(allow)==len(set(allow))
    with tempfile.TemporaryDirectory(prefix="attention-bundle-") as td:
        pack=Path(td)/NAME;pack.mkdir()
        for n in allow:
            p=ROOT/n
            if not p.is_file(): raise FileNotFoundError(p)
            dest=pack/n;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,dest)
        (pack/"verify_upload.py").write_text(VERIFY,encoding="utf-8",newline="\n")
        listing=sorted(allow+["verify_upload.py","UPLOAD_FILE_LIST.txt","UPLOAD_MANIFEST.json"])
        (pack/"UPLOAD_FILE_LIST.txt").write_text("\n".join(listing)+"\n",encoding="utf-8",newline="\n")
        hashes={n:hashlib.sha256((pack/n).read_bytes()).hexdigest() for n in listing if n!="UPLOAD_MANIFEST.json"}
        manifest=dict(created=datetime.now().isoformat(timespec="seconds"),
                      top="attention_head_16ctx_4dim_eval",scope="single_query_single_head_fp32",
                      files=hashes,excluded="Licensed SMIC/DW libraries; synthetic DW; simulator; old upload/history/results")
        (pack/"UPLOAD_MANIFEST.json").write_text(json.dumps(manifest,indent=2)+"\n",encoding="utf-8",newline="\n")
        zipped=Path(td)/(NAME+".zip")
        with zipfile.ZipFile(zipped,"w",zipfile.ZIP_DEFLATED) as z:
            for n in listing: z.write(pack/n,NAME+"/"+n)
        with zipfile.ZipFile(zipped) as z:
            assert z.testzip() is None
            assert set(z.namelist())=={NAME+"/"+n for n in listing}
            for n,h in hashes.items(): assert hashlib.sha256(z.read(NAME+"/"+n)).hexdigest()==h
        old=[OUTPUT/NAME,OUTPUT/(NAME+".zip")]
        if any(p.exists() for p in old):
            history=ROOT.parent/"_history"/("upload_rebuild_"+datetime.now().strftime("%Y%m%d_%H%M%S_%f"))
            history.mkdir(parents=True)
            for p in old:
                resolved=p.resolve()
                assert resolved.parent==OUTPUT.resolve()
                if p.exists(): shutil.move(str(resolved),str(history/p.name))
        shutil.copytree(pack,OUTPUT/NAME)
        shutil.copyfile(zipped,OUTPUT/(NAME+".zip"))
    (OUTPUT/"README.md").write_text(
        "# 上传说明\n\n只需上传 [attention_16x4_synopsys_upload.zip](attention_16x4_synopsys_upload.zip)。\n\n"
        "解压后进入同名目录，复制 [完整 Codex 提示词](attention_16x4_synopsys_upload/synopsys/PROMPT_SYNOPSYS.md) 给服务器 Codex。\n\n"
        "[文件清单](attention_16x4_synopsys_upload/UPLOAD_FILE_LIST.txt)；"
        "[完整说明](attention_16x4_synopsys_upload/README.md)；"
        "[MAC 相减契约](attention_16x4_synopsys_upload/synopsys/MEASUREMENT_CONTRACT.md)。\n\n"
        "服务器需本地提供 SMIC 28nm 库、官方 DesignWare 和工具许可证。"
        "要求 TOTAL 与16个 u_mac 同一网表、同一完整命令窗口；不能按周期比例分摊面积/能量。"
        "返回 reviewed JSON、分项面积/功率报告、STA、windows.json 后可相减。"
        "本地功能验证已完成，真实 SMIC PPA 待服务器测量。\n",
        encoding="utf-8",newline="\n")
    print(OUTPUT/(NAME+".zip"))
    print(f"PASS {len(listing)} files; expanded folder and ZIP hashes match")

if __name__=="__main__": main()
