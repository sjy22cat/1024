"""Accounting checks: disjoint ownership, shared window and unit conversion."""
import copy
import json
from pathlib import Path
import unittest
from subtract_mac import subtract

def fixture():
    d=json.loads((Path(__file__).parent/"measurement.template.json").read_text(encoding="utf-8"))
    d.update(netlist_sha256="test-only-netlist",period_ns=1.0,cycles=dict(total=121,qk=24,pv=18))
    d["checks"]={k:True for k in d["checks"]}
    d["area"]={"total_um2":100,"mac_instances":[dict(instance=f"g_context[{i}]/u_lane/u_mac",area_um2=4) for i in range(16)]}
    d["power_samples"]=[dict(seed=1,netlist_sha256=d["netlist_sha256"],window_start_ns=10.5,window_end_ns=131.5,
        total=dict(internal_w=.002,switching_w=.001,leakage_w=.0001),
        mac_instances=[dict(instance=x["instance"],internal_w=.00005,switching_w=.000025,leakage_w=.000001)
                       for x in d["area"]["mac_instances"]])]
    return d

class SubtractionTest(unittest.TestCase):
    def test_subtract_units(self):
        r=subtract(fixture())
        self.assertEqual(r["latency"]["valid_residual_ns"],79)
        self.assertEqual(r["area"]["nonmac_residual_um2"],36)
        self.assertAlmostEqual(r["energy"][0]["nonmac_residual"]["dynamic_pj"],217.8)
        self.assertAlmostEqual(r["energy"][0]["nonmac_residual"]["leakage_pj"],10.164)

    def test_timing_failure_is_diagnostic(self):
        d=fixture();d["checks"]["setup_pass"]=False;r=subtract(d)
        self.assertIsNone(r["latency"]["valid_residual_ns"])
        self.assertIsNone(r["energy"][0]["valid_nonmac_total_pj"])
        self.assertEqual(r["status"],"DIAGNOSTIC_TIMING_UNCLOSED")

    def test_bad_partitions_rejected(self):
        for change in ("duplicate", "different_netlist", "different_window", "exceeds_total", "units"):
            d=fixture()
            if change=="duplicate": d["area"]["mac_instances"][1]=copy.deepcopy(d["area"]["mac_instances"][0])
            if change=="different_netlist": d["power_samples"][0]["netlist_sha256"]="other"
            if change=="different_window": d["power_samples"][0]["window_end_ns"]+=1
            if change=="exceeds_total": d["area"]["total_um2"]=1
            if change=="units": d["checks"]["units_verified"]=False
            with self.subTest(change=change),self.assertRaises(ValueError): subtract(d)

    def test_pending_remains_missing(self):
        d=json.loads((Path(__file__).parent/"measurement.template.json").read_text(encoding="utf-8"));r=subtract(d)
        self.assertEqual(r["status"],"PENDING")
        self.assertIsNone(r["latency"])
        self.assertIsNone(r["area"])
        self.assertEqual(r["energy"],[])

if __name__=="__main__": unittest.main()
