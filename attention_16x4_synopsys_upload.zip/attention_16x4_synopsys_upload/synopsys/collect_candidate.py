#!/usr/bin/env python3
"""Gather RAW tool readings. Flags remain false until report audit completes."""
import argparse
import csv
import hashlib
import json
from pathlib import Path

def rows(path):
    if not path.is_file(): return []
    with path.open(encoding="utf-8") as f: return list(csv.DictReader(f,delimiter="\t"))

def val(x):
    try: return float(x)
    except (ValueError,TypeError): return None

def main():
    ap=argparse.ArgumentParser(__doc__)
    ap.add_argument("run_dir",type=Path)
    args=ap.parse_args();r=args.run_dir.resolve()
    manifest=json.loads((r/"run_manifest.json").read_text(encoding="utf-8"));site=manifest["site"]
    net=hashlib.sha256((r/"mapped.v").read_bytes()).hexdigest()
    ar=rows(r/"area_attributes.tsv")
    windows=json.loads((r/"windows.json").read_text(encoding="utf-8"))
    for n in sorted({w["n"] for w in windows}):
        d=json.loads((Path(__file__).parent/"measurement.template.json").read_text(encoding="utf-8"))
        ws=[w for w in windows if w["n"]==n];first=ws[0]
        d.update(n=n,netlist_sha256=net,period_ns=site["period_ns"])
        d["cycles"]={"total":first["cycles"],"qk":first["qk_cycles"],"pv":first["pv_cycles"]}
        for row in ar:
            a=val(row["area_library_units"])
            if a is None: continue
            a*=site["library_area_unit_um2"]
            if row["scope"]=="TOTAL": d["area"]["total_um2"]=a
            else: d["area"]["mac_instances"].append(dict(instance=row["scope"],area_um2=a))
        for w in ws:
            raw=rows(r/(w["tag"]+"_power_attributes.tsv"));total=None;mac=[]
            for row in raw:
                values=[val(row.get(k)) for k in ("internal_power","switching_power","leakage_power")]
                if any(v is None for v in values): continue
                powers=dict(zip(("internal_w","switching_w","leakage_w"),
                                [v*site["tool_power_unit_w"] for v in values]))
                if row["scope"]=="TOTAL": total=powers
                else: mac.append(dict(instance=row["scope"],**powers))
            if total is not None and len(mac)==16:
                d["power_samples"].append(dict(seed=w["seed"],netlist_sha256=net,
                    window_start_ns=w["window_start_ns"],window_end_ns=w["window_end_ns"],
                    total=total,mac_instances=mac))
        d["evidence"]=[p.name for p in r.glob("*.rpt")]+["run_manifest.json","windows.json","mac_instances.txt"]
        out=r/f"measurement_n{n}.candidate.json"
        out.write_text(json.dumps(d,indent=2)+"\n")
        print("RAW candidate (requires report/unit/partition audit):",out)
    print("Do not set checks to true merely because attributes were available.")

if __name__=="__main__": main()
