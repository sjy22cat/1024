#!/usr/bin/env python3
"""Subtract matching MAC ownership, preserving pending/diagnostic status."""
import argparse
import json
import math
from pathlib import Path

def number(x,name):
    if isinstance(x,bool) or not isinstance(x,(int,float)) or not math.isfinite(x) or x<0:
        raise ValueError(f"Invalid {name}: {x}")
    return x

def difference(total,mac,name):
    number(total,name);number(mac,name+" MAC")
    if mac>total+max(1e-9,total*1e-6): raise ValueError(f"MAC exceeds total: {name}")
    return max(0.0,total-mac)

def owners(items):
    names=[i["instance"] for i in items]
    if len(names)!=16 or len(set(names))!=16 or any(not n.endswith("/u_mac") for n in names):
        raise ValueError("Require exactly 16 distinct /u_mac owners from mapped hierarchy")
    return set(names)

def subtract(d):
    if d["scope"]!="single_query_single_head_fp32" or d["top"]!="attention_head_16ctx_4dim_eval":
        raise ValueError("Unsupported head/group/cohort scope; cannot mix normalizations")
    c=d["checks"]
    closed=all(c.get(k,False) for k in ("official_dw_function_pass","complete_mapping_no_blackboxes",
                                      "units_verified","setup_pass","hold_pass","electrical_pass","sta_coverage_audited"))
    result={"scope":d["scope"],"n":d["n"],"netlist_sha256":d["netlist_sha256"],
            "timing_closed":closed,"latency":None,"area":None,"energy":[],
            "latency_interpretation":"Residual scheduled time includes load/control and removes PV-overlapped denominator work from the elapsed-time attribution; it is not isolated non-MAC operator latency."}
    cy=d["cycles"];p=d["period_ns"]
    if p is not None and all(cy.get(k) is not None for k in ("total","qk","pv")):
        number(p,"period_ns")
        if p==0: raise ValueError("period must be positive")
        for k in ("total","qk","pv"):
            number(cy[k],k)
            if cy[k]!=int(cy[k]): raise ValueError("Cycle counts must be integers")
        mac=cy["qk"]+cy["pv"];res=difference(cy["total"],mac,"cycles")
        result["latency"]={"cycles_total":cy["total"],"cycles_mac_phases":mac,"cycles_residual":res,
                           "nominal_total_ns":cy["total"]*p,"nominal_mac_phase_ns":mac*p,
                           "nominal_residual_ns":res*p,
                           "valid_total_ns":cy["total"]*p if closed else None,
                           "valid_mac_phase_ns":mac*p if closed else None,
                           "valid_residual_ns":res*p if closed else None}
    area=d["area"]
    if area.get("total_um2") is not None:
        for k in ("complete_mapping_no_blackboxes","units_verified","same_netlist_partition_verified",
                  "hierarchical_area_reconciled_with_leaf_cells"):
            if not c.get(k): raise ValueError("Area not verified: "+k)
        if not d.get("netlist_sha256"): raise ValueError("Missing netlist identity")
        names=owners(area["mac_instances"])
        am=sum(number(x["area_um2"],"MAC area") for x in area["mac_instances"])
        result["area"]={"total_um2":area["total_um2"],"mac_um2":am,
                        "nonmac_residual_um2":difference(area["total_um2"],am,"area")}
    else: names=None
    for sample in d["power_samples"]:
        for k in ("official_dw_function_pass","complete_mapping_no_blackboxes","units_verified",
                  "same_netlist_partition_verified","activity_window_and_coverage_verified","hierarchical_power_reconciled"):
            if not c.get(k): raise ValueError("Power not verified: "+k)
        if not d.get("netlist_sha256") or sample["netlist_sha256"]!=d["netlist_sha256"]:
            raise ValueError("Power uses a different/missing netlist identity")
        sample_names=owners(sample["mac_instances"])
        if names is not None and sample_names!=names: raise ValueError("Area/power MAC ownership differs")
        if result["latency"] is None: raise ValueError("Need measured command cycles/period for power")
        start=number(sample["window_start_ns"],"window start")
        end=number(sample["window_end_ns"],"window end");ns=end-start
        if ns<=0 or abs(ns-result["latency"]["nominal_total_ns"])>1e-5:
            raise ValueError("Power window differs from handshake-to-first-valid latency")
        total={k:number(sample["total"][k],k) for k in ("internal_w","switching_w","leakage_w")}
        mac={k:sum(number(x[k],k) for x in sample["mac_instances"]) for k in total}
        residual={k:difference(total[k],mac[k],k) for k in total}
        def energy(v):
            dyn=(v["internal_w"]+v["switching_w"])*ns*1000.0
            leak=v["leakage_w"]*ns*1000.0
            return {"dynamic_pj":dyn,"leakage_pj":leak,"total_pj":dyn+leak}
        e={"seed":sample["seed"],"window_ns":ns,"status":"VALID_PRELAYOUT" if closed else "DIAGNOSTIC_TIMING_UNCLOSED",
           "attention":energy(total),"mac":energy(mac),"nonmac_residual":energy(residual)}
        e["valid_nonmac_total_pj"]=e["nonmac_residual"]["total_pj"] if closed else None
        result["energy"].append(e)
    result["status"]="PENDING" if result["area"] is None or not result["energy"] or result["latency"] is None else ("VALID_PRELAYOUT" if closed else "DIAGNOSTIC_TIMING_UNCLOSED")
    return result

def main():
    ap=argparse.ArgumentParser(__doc__)
    ap.add_argument("measurement",type=Path)
    ap.add_argument("--output",type=Path,required=True)
    args=ap.parse_args()
    result=subtract(json.loads(args.measurement.read_text(encoding="utf-8")))
    args.output.parent.mkdir(parents=True,exist_ok=True)
    args.output.write_text(json.dumps(result,indent=2,ensure_ascii=False)+"\n",encoding="utf-8")
    print(json.dumps(result,indent=2,ensure_ascii=False))

if __name__=="__main__": main()
