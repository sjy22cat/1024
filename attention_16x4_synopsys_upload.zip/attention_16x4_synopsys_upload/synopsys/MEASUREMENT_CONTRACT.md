# Attention 总量及非 MAC 计量口径

## 主对象与配置

本交付默认只综合 `attention_head_16ctx_4dim_eval`：一个 Q、N 行 K/V、一个 128 维 O。

| 参数 | 值 |
|---|---:|
| HEAD_DIM | 128 |
| TILE_SIZE | 32 |
| CONTEXT_PARALLEL | 16 |
| KV_LOAD_PARALLEL | 16 |
| MAX_CONTEXT | 1152 |
| SCALE_BITS | 0x3db504f3 |

这是单 head FP32 evaluator，64 个逻辑 32×32 乘法/归约平面。没有物理 MXFP4 PE、MEM die、GSRAM、PHY 或真实 SRAM 宏。K/V bank 按寄存器映射，其面积和活动包含在总量中。独立 Q 头、GQA group 和 16-head cohort 不能共用同一个“每命令”分母。

源码另外提供 GQA query block 和 cohort，供后续系统集成。**默认综合脚本不把它们实例化在主对象内**。若另测 GQA，必须另建配置、TB、数据文件和面积/能量分母；不能将本次单头数据标作完整 query-block 或 16-head 系统测量。

## MAC 电路边界

每个 `g_context[i]/u_lane/u_mac`（共 16 个）包括：

- QK 与 PV 复用的乘法器、乘法结果寄存器和注册加法归约树。
- 四个 head-dim 分块的 QK 合并加法及 score 寄存器。
- 这些资源自己的操作数选择、局部有效性门控及寄存器写使能逻辑。

其余归为 residual：query 缩放、局部 max/diff/exp、分母求和、context/running merge、倒数/输出缩放、共享 FSM/控制、K/V 和其他非 MAC 状态寄存器、边界之外的缓冲/网络。**merge/归一化中的 FP 乘法器属于 residual**。按功能归属划分，不能把全部 `DW_fp_mult` 都减掉。

MAC 层次在映射时保留，内部门仍要真实映射；不能在未映射时 `dont_touch u_mac` 而留下黑盒。QK/PV 复用的同一套单元面积只算一次。此分区会限制跨边界优化，结果表征这份分层实现。

residual 不是纯 Softmax 面积，也不是最终复用物理 MXFP4 阵列后的增量面积。如果模拟器另计 K/V SRAM/buffer，需另报这些 bank 的面积/能耗后再处理，不能把当前寄存器 bank 再计一次。

## 延迟：按调度相减

从命令 `valid && ready` 的上升沿到首次 `o_valid`，不含输出背压。N 合法、输入及时、默认配置下预期：

`waves = ceil(N/512)`；`cycles_total = 39*waves + 4`。

| N=1152 阶段 | 周期 |
|---|---:|
| Query 预缩放 | 1 |
| 首波外露 KV 装载 | 1 |
| 三次 wave 启动 | 3 |
| QK 乘法、归约及维度合并 | 24 |
| 局部 max/diff/exp | 21 |
| PV 与并行分母归约 | 18 |
| Context 统一 max 后并行归约 | 33 |
| Running online merge | 15 |
| 状态提交 | 3 |
| 倒数与最终缩放 | 2 |
| 总计 | 121 |

调度归因：MAC = QK 24 + PV 18 = 42 拍；residual = 121 − 42 = 79 拍。
其中纯非 MAC 算术 72 拍，装载/启动/提交共 7 拍。
分母求和与 PV 同时执行；将整个 PV 阶段归给 MAC 后，它不再单独增加 residual 墙钟时间。这不表示分母电路没有面积或能耗。

TB 会实测并输出 `MAC_SCHEDULE`，不能只抄上述预期。对于其他 N，MAC 预期 `14*waves`，residual 预期 `25*waves+4`；新增停顿必须另记。

如果真实可用周期为 T ns，则总时间 `C*T`、MAC 阶段 `Cmac*T`、调度余项 `(C−Cmac)*T`。
1 ns 未通过时，121/42/79 ns 只能放在 nominal 字段。不能用单个算子 delay 的 ceil 或 WNS 给全模块自动“修正”到 1 ns；插入流水级会改变依赖/握手和周期，需要改 RTL 后重测。
实际闭合要求 setup、hold 和电气约束全部通过，功能正确且检查覆盖已审计。无需声称获得精确 Fmax。

## 面积：同一网表的电路分区

`Aresidual_um2 = Atotal_um2 − sum(A_u_mac_um2)`。

要求完整映射、同一 .db/单位、同一网表、16 个互不重叠 MAC 实例；用叶标准单元面积和核对层次聚合。若 344M 级实例的逐项循环受限，可按模块/标准单元 reference 计数聚合再核对；不可因工具内存不够改小参数冒充默认实现。
返回标准单元面积，排除利用率留白、IO、布线和未实现 CTS。无宏时明确 `macro_area=0`。

## 能耗：同一网表、同一完整命令窗口

先在同一活动窗口内获取 TOTAL 与 16 个 MAC 子树的 internal/switching/leakage 功率，核对层次计费规则：单元内部功率按实例归属，网络开关功率按驱动者归属，边界网络/常量/时钟/上层缓冲只计一次。**MAC 子树的能耗必须包含其在非 MAC 阶段的时钟和漏电活动**，不能只截取 QK/PV 活跃时间。

功率换成 W、时间换成 ns：

```
E_dynamic_pJ = (P_internal_W + P_switching_W) * window_ns * 1000
E_leakage_pJ = P_leakage_W * window_ns * 1000
E_total_pJ   = E_dynamic_pJ + E_leakage_pJ
E_residual_* = E_attention_* - sum(E_mac_*)
```

1 mW × 1 ns = 1 pJ。面积/能耗不能乘以 `42/121` 推算 MAC 占比。禁止减掉“单独综合的另一份 MAC”或不同时钟/输入/窗口的能量。共享时钟网络和上层控制留在 residual，按上述约定明确披露。

默认 3 个种子、非零随机 Q/K/V，范围分别约 [-0.5,0.5]、[-0.5,0.5]、[-1,1]。活动 VCD 可覆盖整个仿真，但 PrimePower 只读取 TB 打印的命令窗口；排除复位、初始中止、空闲和输出背压。核实 `read_vcd -time` 在工具版本中的单位及实际窗口，输出直接/传播/默认/未标注活动覆盖率。
先完成官方 DW 数值验证，再看能耗。RTL 活动传播无门级延迟毛刺，且无 CTS/SPEF；即使时序通过也只标作布局前估计。若未闭合或库 slew/load 大量外推，保留诊断值、失败原因与原始报告，不能发布有效 1 GHz 能量。

## 校准数据及相减

`collect_candidate.py` 只收集原始读数，所有审计标志初始 false。Codex 需对照原始报告、工具 `help` 和单位完成核对，写出 `measurement_nN.reviewed.json`；没有证据的项保留 PENDING/false/null。`subtract_mac.py` 对不匹配范围、负余项、重复 MAC、不同网表或不同窗口拒绝相减；时序失败时仅输出 nominal/diagnostic，不产生 valid 延迟/能量。

最终返回：TOTAL、MAC、residual 三列的 ns/µm²/pJ，以及动态/漏电/总能量、三个种子的 mean/min/max。不要自动覆盖 SIM-1023 已有参数；待结果返回后再由本地审查是否符合模拟器计费范围。
