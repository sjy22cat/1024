#!/usr/bin/env python3
"""Linux/Synopsys entry point. No vendor paths, fake IP, or PPA defaults."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess

ROOT=Path(__file__).resolve().parents[1]

def sha(path): return hashlib.sha256(path.read_bytes()).hexdigest()

def tcl_word(x):
    s=str(x).replace("\\", "/")
    if any(c in s for c in "{}\n\r"): raise ValueError("Unsupported Tcl path/value: "+s)
    return "{"+s+"}"

def execute(cmd,log,env):
    print("RUN", *cmd, flush=True)
    with log.open("w") as out:
        result=subprocess.run(cmd,cwd=ROOT,env=env,stdout=out,stderr=subprocess.STDOUT)
    if result.returncode: raise RuntimeError(f"Command failed ({result.returncode}); see {log}")
    # Synopsys Tcl errors may otherwise return process status 0.
    data=log.read_text(encoding="utf-8",errors="replace")
    if re.search(r"(?m)^\s*(?:Error:|FATAL:|Fatal:)",data):
        raise RuntimeError(f"Tool reported errors; see {log}")

def write_config(site,out,extra=None):
    values=dict(site)
    values["run_dir"]=out.as_posix()
    values["db_search_dirs"]=sorted({str(Path(x).parent) for x in site["target_db"]+site["extra_link_db"]})
    if extra: values.update(extra)
    lines=[]
    for k,v in values.items():
        if isinstance(v,list): expr="[list "+" ".join(tcl_word(i) for i in v)+"]"
        else: expr=tcl_word(v)
        lines.append("set "+k+" "+expr)
    dest=out/"site_config.tcl"
    dest.write_text("\n".join(lines)+"\n",encoding="utf-8")
    return dest

def windows(log):
    text=log.read_text(encoding="utf-8")
    ends=re.findall(r"MEASURE_END n=(\d+) begin_ns=([\d.]+) end_ns=([\d.]+) cycles=(\d+) kv_load_cycles=(\d+) prefetched_tiles=(\d+)",text)
    macs=re.findall(r"MAC_SCHEDULE qk_cycles=(\d+) pv_cycles=(\d+) residual_cycles=(\d+)",text)
    if len(ends)!=1 or len(macs)!=1 or "PASS command errors" not in text or "FATAL" in text:
        raise ValueError(f"Incomplete or failed activity run: {log}")
    n,start,end,cyc,loads,prefetch=ends[0]
    qk,pv,res=map(int,macs[0])
    assert qk+pv+res==int(cyc)
    return dict(n=int(n),window_start_ns=float(start),window_end_ns=float(end),
                cycles=int(cyc),qk_cycles=qk,pv_cycles=pv,residual_cycles=res,
                kv_load_handshakes=int(loads),prefetched_handshakes=int(prefetch))

def main():
    ap=argparse.ArgumentParser(__doc__)
    ap.add_argument("--site",default="synopsys/site.json")
    ap.add_argument("--run-dir",default="results/smic28_1ns")
    ap.add_argument("--stage",choices=["sim","dc","sta","power","all"],required=True)
    ap.add_argument("--contexts",default="1152")
    ap.add_argument("--seeds",default="20261023,20261024,20261025")
    ap.add_argument("--period-ns",type=float)
    args=ap.parse_args()
    os.chdir(ROOT)
    site=json.loads(Path(args.site).read_text(encoding="utf-8"))
    if args.period_ns is not None: site["period_ns"]=args.period_ns
    if site["period_ns"]<=0: raise ValueError("period_ns must be positive")
    for x in site["target_db"]+site["extra_link_db"]:
        if not Path(x).is_file(): raise FileNotFoundError(x)
    if not Path(site["dw_sim_dir"]).is_dir(): raise FileNotFoundError(site["dw_sim_dir"])
    out=Path(args.run_dir).resolve();out.mkdir(parents=True,exist_ok=True)
    env=os.environ.copy()
    cfg=write_config(site,out)
    env["ATTN_CONFIG_TCL"]=str(cfg)
    sources=(ROOT/"sources.f").read_text(encoding="utf-8").splitlines()
    source_hashes={x:sha(ROOT/x) for x in sources}
    manifest=dict(top="attention_head_16ctx_4dim_eval",head_dim=128,tile_size=32,
                  context_parallel=16,kv_load_parallel=16,max_context=1152,
                  source_sha256=source_hashes,site=site,
                  note="FP32 evaluator; no physical MXFP4 array, GSRAM, PHY or CTS")
    # Prevent mixing a changed RTL/config with an old mapped netlist/activity.
    mp=out/"run_manifest.json"
    if mp.exists() and json.loads(mp.read_text(encoding="utf-8"))!=manifest:
        raise ValueError("Existing run uses different RTL/config. Choose a new --run-dir.")
    mp.write_text(json.dumps(manifest,indent=2)+"\n")
    stages=["sim","dc","sta","power"] if args.stage=="all" else [args.stage]
    for stage in stages:
        if stage=="sim":
            sf=out/"sim_sources.f"
            sf.write_text("verification/nonmac_tb_math.sv\n"+"\n".join(sources)+"\ntb_attention_head_16ctx_4dim.sv\n")
            simv=out/"simv"
            execute(["vcs","-full64","-sverilog","-timescale=1ns/1ps","-debug_access+all",
                     "-top","tb_attention_head_16ctx_4dim","-f",str(sf),"-y",site["dw_sim_dir"],
                     "+libext+.v+.sv","-o",str(simv)],out/"vcs_compile.log",env)
            records=[]
            for n in map(int,args.contexts.split(",")):
                if not 1<=n<=1152: raise ValueError("Context out of range")
                for seed in map(int,args.seeds.split(",")):
                    tag=f"n{n}_seed{seed}"
                    vcd=out/(tag+".vcd");log=out/(tag+".log")
                    execute([str(simv),f"+CONTEXT_N={n}",f"+SEED={seed}",
                             f"+CLOCK_NS={site['period_ns']}","+POWER_ACTIVITY",f"+DUMP_VCD={vcd}"],log,env)
                    record=windows(log)
                    assert abs(record["cycles"]*site["period_ns"]-(record["window_end_ns"]-record["window_start_ns"]))<1e-5
                    record.update(seed=seed,tag=tag,activity_vcd=str(vcd),activity_sha256=sha(vcd))
                    records.append(record)
            (out/"windows.json").write_text(json.dumps(records,indent=2)+"\n")
        elif stage=="dc":
            env["ATTN_STAGE"]="dc"
            execute(["dc_shell","-f","synopsys/dc.tcl"],out/"dc.log",env)
            if not (out/"mapped.v").is_file(): raise RuntimeError("No complete mapped netlist")
        else:
            env["ATTN_STAGE"]=stage
            if not (out/"mapped.v").is_file(): raise RuntimeError("Run DC first")
            if stage=="sta":
                write_config(site,out)
                execute(["pt_shell","-f","synopsys/pt.tcl"],out/"pt.log",env)
            else:
                if not isinstance(site.get("read_vcd_time_unit_ns"),(int,float)) or site["read_vcd_time_unit_ns"]<=0:
                    raise ValueError("Confirm read_vcd -time units and set read_vcd_time_unit_ns before power; do not guess")
                for w in json.loads((out/"windows.json").read_text(encoding="utf-8")):
                    if sha(Path(w["activity_vcd"]))!=w["activity_sha256"]: raise ValueError("VCD changed")
                    write_config(site,out,dict(window_start_ns=w["window_start_ns"],window_end_ns=w["window_end_ns"],
                                              activity_vcd=w["activity_vcd"],power_tag=w["tag"]))
                    execute(["pt_shell","-f","synopsys/pt.tcl"],out/(w["tag"]+"_pt_power.log"),env)
    print("Reports:",out)
    print("Complete measurement.template.json from audited reports; then run subtract_mac.py.")

if __name__=="__main__": main()
