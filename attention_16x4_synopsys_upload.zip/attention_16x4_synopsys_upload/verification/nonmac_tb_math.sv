`timescale 1ns/1ps
package nonmac_test_math;
 function automatic real fp_real(input [31:0] x);
  real v;
  begin
   v=(x[30:23]==0)?(x[22:0]*2.0**(-149)):
      ((1.0+x[22:0]/8388608.0)*2.0**($signed({1'b0,x[30:23]})-127));
   fp_real=x[31]?-v:v;
  end
 endfunction
 function automatic [31:0] real_fp(input real x);
  real v,f;
  integer e,q;
  reg sign_bit;
  reg [31:0] bits;
  begin
   sign_bit=(x<0);v=sign_bit?-x:x;e=0;bits=0;
   if(v!=0) begin
    while(v>=2.0&&e<128) begin v=v/2.0;e=e+1;end
    while(v<1.0&&e > -150) begin v=v*2.0;e=e-1;end
    if(e>127) bits=32'h7f800000;
    else begin
     f=(e < -126)?v*2.0**(e+149):v*8388608.0;
     q=$rtoi(f);
     if(f-q>0.5 || (f-q==0.5 && q[0])) q=q+1;
     if(e < -126) bits=q;
     else begin
      if(q==16777216) begin q=q>>1;e=e+1;end
      bits=((e+127)<<23)|(q&23'h7fffff);
     end
    end
    bits[31]=sign_bit;
   end
   real_fp=bits;
  end
 endfunction
endpackage
