`timescale 1ns/1ps

// Five registered stages: max -> differences -> exp -> products -> sums.
// i_fire is a pulse. Transactions must be at least five cycles apart (the
// wide l/z operands are retained, rather than shifted through every stage).
// i_a_present/i_b_present describe mathematical empty states independently
// of the transaction-valid strobes. Empty inputs may contain arbitrary bits.
module attention_online_merge_fp32 #(
    parameter integer HEAD_DIM = 128
) (
    input wire clk, rst_n,
    input wire i_fire,
    input wire i_a_present, i_b_present,
    input wire [31:0] i_a_m, i_a_l, i_b_m, i_b_l,
    input wire [HEAD_DIM*32-1:0] i_a_z, i_b_z,
    output wire o_fire,
    output reg o_present,
    output reg [31:0] o_m, o_l,
    output reg [HEAD_DIM*32-1:0] o_z
);
    reg [4:0] valid_q;
    reg a_present_q, b_present_q;
    reg [31:0] a_m_q, b_m_q, max_q, a_l_q, b_l_q;
    reg [HEAD_DIM*32-1:0] a_z_q, b_z_q;
    reg [31:0] a_diff_q, b_diff_q, a_alpha_q, b_alpha_q;
    reg [31:0] a_lp_q, b_lp_q;
    reg [HEAD_DIM*32-1:0] a_zp_q, b_zp_q;

    function automatic [31:0] fp_max(input [31:0] a, b);
        if (a[31] != b[31]) fp_max = a[31] ? b : a;
        else if (a[31]) fp_max = (a[30:0] < b[30:0]) ? a : b;
        else fp_max = (a[30:0] > b[30:0]) ? a : b;
    endfunction

    wire [31:0] a_diff, b_diff, a_exp, b_exp, a_lp, b_lp, l_sum;
    wire [HEAD_DIM*32-1:0] a_zp, b_zp, z_sum;
    wire [7:0] status_unused [0:6];
    DW_fp_addsub #(.sig_width(23), .exp_width(8), .ieee_compliance(0)) u_a_diff (
        .a(a_present_q ? a_m_q : max_q), .b(max_q), .rnd(3'b000),
        .op(1'b1), .z(a_diff), .status(status_unused[0]));
    DW_fp_addsub #(.sig_width(23), .exp_width(8), .ieee_compliance(0)) u_b_diff (
        .a(b_present_q ? b_m_q : max_q), .b(max_q), .rnd(3'b000),
        .op(1'b1), .z(b_diff), .status(status_unused[1]));
    DW_fp_exp #(.sig_width(23), .exp_width(8), .ieee_compliance(0), .arch(2)) u_a_exp (
        .a(a_diff_q), .z(a_exp), .status(status_unused[2]));
    DW_fp_exp #(.sig_width(23), .exp_width(8), .ieee_compliance(0), .arch(2)) u_b_exp (
        .a(b_diff_q), .z(b_exp), .status(status_unused[3]));
    DW_fp_mult #(.sig_width(23), .exp_width(8), .ieee_compliance(0)) u_a_l (
        .a(a_l_q), .b(a_alpha_q), .rnd(3'b000), .z(a_lp), .status(status_unused[4]));
    DW_fp_mult #(.sig_width(23), .exp_width(8), .ieee_compliance(0)) u_b_l (
        .a(b_l_q), .b(b_alpha_q), .rnd(3'b000), .z(b_lp), .status(status_unused[5]));
    DW_fp_addsub #(.sig_width(23), .exp_width(8), .ieee_compliance(0)) u_l_sum (
        .a(a_lp_q), .b(b_lp_q), .rnd(3'b000), .op(1'b0),
        .z(l_sum), .status(status_unused[6]));

    genvar d;
    generate for (d = 0; d < HEAD_DIM; d = d + 1) begin : g_z
        wire [7:0] sa, sb, ss;
        DW_fp_mult #(.sig_width(23), .exp_width(8), .ieee_compliance(0)) u_a (
            .a(a_z_q[d*32 +: 32]), .b(a_alpha_q), .rnd(3'b000),
            .z(a_zp[d*32 +: 32]), .status(sa));
        DW_fp_mult #(.sig_width(23), .exp_width(8), .ieee_compliance(0)) u_b (
            .a(b_z_q[d*32 +: 32]), .b(b_alpha_q), .rnd(3'b000),
            .z(b_zp[d*32 +: 32]), .status(sb));
        DW_fp_addsub #(.sig_width(23), .exp_width(8), .ieee_compliance(0)) u_sum (
            .a(a_zp_q[d*32 +: 32]), .b(b_zp_q[d*32 +: 32]),
            .rnd(3'b000), .op(1'b0), .z(z_sum[d*32 +: 32]), .status(ss));
    end endgenerate

    assign o_fire = valid_q[4];
    // Only control needs reset. All data registers are written before use.
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) valid_q <= 0;
        else valid_q <= {valid_q[3:0], i_fire};
    end
    always @(posedge clk) begin
        if (rst_n) begin
            if (i_fire) begin
                a_present_q <= i_a_present;
                b_present_q <= i_b_present;
                a_m_q <= i_a_present ? i_a_m : 32'b0;
                b_m_q <= i_b_present ? i_b_m : 32'b0;
                max_q <= i_a_present ? (i_b_present ? fp_max(i_a_m, i_b_m) : i_a_m) :
                         (i_b_present ? i_b_m : 32'b0);
                a_l_q <= i_a_present ? i_a_l : 32'b0;
                b_l_q <= i_b_present ? i_b_l : 32'b0;
                a_z_q <= i_a_present ? i_a_z : {HEAD_DIM*32{1'b0}};
                b_z_q <= i_b_present ? i_b_z : {HEAD_DIM*32{1'b0}};
            end
            if (valid_q[0]) begin
                a_diff_q <= a_diff;
                b_diff_q <= b_diff;
            end
            if (valid_q[1]) begin
                a_alpha_q <= a_present_q ? a_exp : 32'b0;
                b_alpha_q <= b_present_q ? b_exp : 32'b0;
            end
            if (valid_q[2]) begin
                a_lp_q <= a_lp; b_lp_q <= b_lp;
                a_zp_q <= a_zp; b_zp_q <= b_zp;
            end
            if (valid_q[3]) begin
                o_present <= a_present_q | b_present_q;
                o_m <= max_q; o_l <= l_sum; o_z <= z_sum;
            end
        end
    end
endmodule
