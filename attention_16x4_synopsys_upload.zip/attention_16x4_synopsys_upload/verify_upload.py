from pathlib import Path
import hashlib,json
r=Path(__file__).resolve().parent
m=json.loads((r/"UPLOAD_MANIFEST.json").read_text(encoding="utf-8"))
bad=[n for n,h in m["files"].items() if not (r/n).is_file() or hashlib.sha256((r/n).read_bytes()).hexdigest()!=h]
if bad: raise SystemExit("Missing/changed files: "+str(bad))
sources=(r/"sources.f").read_text(encoding="utf-8").splitlines()
assert len(sources)==7 and all((r/n).is_file() for n in sources)
assert not (r/"verification/nonmac_test_dw.sv").exists()
print("PASS upload SHA256:",len(m["files"]),"files; 7 RTL sources; no synthetic DW models")
