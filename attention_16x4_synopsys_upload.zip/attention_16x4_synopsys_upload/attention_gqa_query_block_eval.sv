`timescale 1ns/1ps

// One KV head / GQA_GROUP Q heads. Eight default instances occupy 1024
// logical MAC tiles. Query blocks reuse ONE shared context-wave KV bank;
// query arithmetic is time multiplexed, not replicated QUERY_BLOCK times.
// Full FP32 evaluation graph; physical MXFP4 conversion remains external.
module attention_gqa_query_block_eval #(
    parameter integer TILE_SIZE=32,
    parameter integer HEAD_DIM=128,
    parameter integer CONTEXT_PARALLEL=16,
    parameter integer GQA_GROUP=2,
    parameter integer QUERY_BLOCK=4,
    parameter integer MAX_CONTEXT=1152,
    parameter [31:0] SCALE_BITS=32'h3db504f3
) (
    input wire clk, rst_n,
    input wire i_cmd_valid,
    output wire o_cmd_ready,
    input wire [10:0] i_first_context, // inclusive visible length of query 0
    input wire [15:0] i_query_count,
    input wire [QUERY_BLOCK*GQA_GROUP*HEAD_DIM*32-1:0] i_queries,
    // Decode-only newest K/V: used directly and independently appended.
    input wire i_new_kv,
    input wire [HEAD_DIM*32-1:0] i_new_key, i_new_value,
    output wire o_append_valid,
    input wire i_append_ready,
    output wire [10:0] o_append_position,
    output wire [HEAD_DIM*32-1:0] o_append_key, o_append_value,
    // All context lanes have independent inputs, consumed atomically.
    input wire i_kv_valid,
    output wire o_kv_ready,
    output wire [10:0] o_kv_base,
    output wire [CONTEXT_PARALLEL*TILE_SIZE-1:0] o_kv_read_mask,
    input wire [CONTEXT_PARALLEL*TILE_SIZE*HEAD_DIM*32-1:0] i_keys, i_values,
    output wire o_valid,
    input wire i_ready,
    output wire [QUERY_BLOCK*GQA_GROUP*HEAD_DIM*32-1:0] o_results,
    output reg o_error,
    output reg [31:0] o_cycle_count,
    output reg [31:0] o_kv_wave_count
);
    localparam integer WAVE=CONTEXT_PARALLEL*TILE_SIZE;
    localparam integer S_IDLE=0,S_SCALE=1,S_LOAD=2,S_LAUNCH=3,S_WAIT=4,
        S_INV=5,S_NORMALIZE=6,S_RESPONSE=7;
    reg [2:0] state;
    reg [10:0] first_q,total_q,base_q;
    integer count_q,query_q;
    reg new_q,append_pending_q,prefetched_q,prefetch_open_q;
    reg [HEAD_DIM*32-1:0] new_k_q,new_v_q;
    reg [WAVE*HEAD_DIM*32-1:0] keys_q,values_q;
    reg [QUERY_BLOCK*GQA_GROUP*HEAD_DIM*32-1:0] queries_q,scaled_q,results_q;
    reg [GQA_GROUP-1:0] present_q [0:QUERY_BLOCK-1];
    reg [31:0] m_q [0:QUERY_BLOCK-1][0:GQA_GROUP-1];
    reg [31:0] l_q [0:QUERY_BLOCK-1][0:GQA_GROUP-1];
    reg [HEAD_DIM*32-1:0] z_q [0:QUERY_BLOCK-1][0:GQA_GROUP-1];
    reg [31:0] inverse_q [0:GQA_GROUP-1];
    wire [GQA_GROUP-1:0] merged_fire,merged_present;
    wire [31:0] merged_m [0:GQA_GROUP-1],merged_l [0:GQA_GROUP-1];
    wire [HEAD_DIM*32-1:0] merged_z [0:GQA_GROUP-1];
    wire [GQA_GROUP*HEAD_DIM*32-1:0] normalized;
    wire all_merged=&merged_fire;
    wire wave_final=base_q+WAVE>=total_q;
    wire query_final=first_q+query_q<=base_q+WAVE;
    wire query_skip=first_q+query_q<=base_q;
    wire [GQA_GROUP*CONTEXT_PARALLEL-1:0] done;
    wire all_done=&done;
    wire advance=(state==S_WAIT && all_merged && !query_final) ||
                 state==S_NORMALIZE || (state==S_LAUNCH && query_skip);
    assign o_cmd_ready=state==S_IDLE && !append_pending_q;
    assign o_valid=state==S_RESPONSE;
    assign o_results=results_q;
    assign o_append_valid=append_pending_q;
    assign o_append_position=total_q-1'b1;
    assign o_append_key=new_k_q;
    assign o_append_value=new_v_q;
    assign o_kv_ready=state==S_LOAD || (state==S_WAIT && query_q==count_q-1 &&
        !wave_final && !prefetched_q && (prefetch_open_q || all_done));
    assign o_kv_base=state==S_LOAD ? base_q : base_q+WAVE;
    wire kv_accept=o_kv_ready && i_kv_valid;

    initial begin
        if(QUERY_BLOCK<1 || GQA_GROUP<1 || HEAD_DIM!=4*TILE_SIZE ||
           CONTEXT_PARALLEL<2 || (CONTEXT_PARALLEL&(CONTEXT_PARALLEL-1))!=0 ||
           MAX_CONTEXT<1 || MAX_CONTEXT>2047)
            $fatal(1,"invalid GQA query-block configuration");
    end
    genvar h,c,t,d,q;
    generate
        for(t=0;t<WAVE;t=t+1) begin:g_read_mask
            assign o_kv_read_mask[t]=o_kv_ready && o_kv_base+t<total_q &&
                !(new_q && o_kv_base+t==total_q-1);
        end
        for(q=0;q<QUERY_BLOCK;q=q+1) begin:g_query
            for(h=0;h<GQA_GROUP;h=h+1) begin:g_head_scale
                for(d=0;d<HEAD_DIM;d=d+1) begin:g_dim
                    wire [31:0] scaled;
                    wire [7:0] status;
                    DW_fp_mult #(.sig_width(23),.exp_width(8),.ieee_compliance(0)) u_scale(
                        .a(queries_q[((q*GQA_GROUP+h)*HEAD_DIM+d)*32+:32]),
                        .b(SCALE_BITS),.rnd(3'b000),.z(scaled),.status(status));
                    always @(posedge clk) if(rst_n && state==S_SCALE)
                        scaled_q[((q*GQA_GROUP+h)*HEAD_DIM+d)*32+:32]<=scaled;
                end
            end
        end
        for(h=0;h<GQA_GROUP;h=h+1) begin:g_head
            wire [CONTEXT_PARALLEL-1:0] lane_present;
            wire [CONTEXT_PARALLEL*32-1:0] lane_m,lane_l;
            wire [CONTEXT_PARALLEL*HEAD_DIM*32-1:0] lane_z;
            wire context_fire,context_present;
            wire [31:0] context_m,context_l,inverse;
            wire [HEAD_DIM*32-1:0] context_z;
            wire [7:0] inv_status;
            for(c=0;c<CONTEXT_PARALLEL;c=c+1) begin:g_context
                wire [TILE_SIZE-1:0] mask;
                for(t=0;t<TILE_SIZE;t=t+1) begin:g_mask
                    assign mask[t]=base_q+c*TILE_SIZE+t<first_q+query_q;
                end
                attention_context_4dim_lane #(.TILE_SIZE(TILE_SIZE),.HEAD_DIM(HEAD_DIM),
                    .EXTERNAL_KV(1)) u_lane(
                    .clk(clk),.rst_n(rst_n),.i_load(1'b0),.i_token_mask(mask),
                    .i_key(keys_q[c*TILE_SIZE*HEAD_DIM*32+:TILE_SIZE*HEAD_DIM*32]),
                    .i_value(values_q[c*TILE_SIZE*HEAD_DIM*32+:TILE_SIZE*HEAD_DIM*32]),
                    .i_start(state==S_LAUNCH && !query_skip),
                    .i_active(base_q+c*TILE_SIZE<first_q+query_q),
                    .i_query_scaled(scaled_q[(query_q*GQA_GROUP+h)*HEAD_DIM*32+:HEAD_DIM*32]),
                    .o_done(done[h*CONTEXT_PARALLEL+c]),.o_present(lane_present[c]),
                    .o_m(lane_m[c*32+:32]),.o_l(lane_l[c*32+:32]),
                    .o_z(lane_z[c*HEAD_DIM*32+:HEAD_DIM*32]));
            end
            attention_context_reduce_fp32 #(.HEAD_DIM(HEAD_DIM),.CONTEXT_PARALLEL(CONTEXT_PARALLEL)) u_reduce(
                .clk(clk),.rst_n(rst_n),.i_fire(&done[h*CONTEXT_PARALLEL+:CONTEXT_PARALLEL]),
                .i_present(lane_present),.i_m(lane_m),.i_l(lane_l),.i_z(lane_z),
                .o_fire(context_fire),.o_present(context_present),
                .o_m(context_m),.o_l(context_l),.o_z(context_z));
            attention_online_merge_fp32 #(.HEAD_DIM(HEAD_DIM)) u_merge(
                .clk(clk),.rst_n(rst_n),.i_fire(context_fire),
                .i_a_present(present_q[query_q][h]),.i_a_m(m_q[query_q][h]),
                .i_a_l(l_q[query_q][h]),.i_a_z(z_q[query_q][h]),
                .i_b_present(context_present),.i_b_m(context_m),.i_b_l(context_l),.i_b_z(context_z),
                .o_fire(merged_fire[h]),.o_present(merged_present[h]),
                .o_m(merged_m[h]),.o_l(merged_l[h]),.o_z(merged_z[h]));
            DW_fp_div #(.sig_width(23),.exp_width(8),.ieee_compliance(0),.faithful_round(0)) u_inverse(
                .a(32'h3f800000),.b(l_q[query_q][h]),.rnd(3'b000),.z(inverse),.status(inv_status));
            always @(posedge clk) if(rst_n && state==S_INV) inverse_q[h]<=inverse;
            for(d=0;d<HEAD_DIM;d=d+1) begin:g_output
                wire [7:0] status;
                DW_fp_mult #(.sig_width(23),.exp_width(8),.ieee_compliance(0)) u_scale(
                    .a(z_q[query_q][h][d*32+:32]),.b(inverse_q[h]),
                    .rnd(3'b000),.z(normalized[(h*HEAD_DIM+d)*32+:32]),.status(status));
            end
        end
    endgenerate
    integer iq,ih,it;
    always @(posedge clk or negedge rst_n) begin
        if(!rst_n) begin
            state<=S_IDLE;first_q<=0;total_q<=0;base_q<=0;count_q<=1;query_q<=0;
            new_q<=0;append_pending_q<=0;prefetched_q<=0;prefetch_open_q<=0;
            o_error<=0;o_cycle_count<=0;o_kv_wave_count<=0;
            for(iq=0;iq<QUERY_BLOCK;iq=iq+1) present_q[iq]<=0;
        end else begin
            if(state!=S_IDLE && state!=S_RESPONSE) o_cycle_count<=o_cycle_count+1;
            if(o_append_valid && i_append_ready) append_pending_q<=0;
            if(state==S_WAIT && query_q==count_q-1 && all_done) prefetch_open_q<=1;
            if(kv_accept) begin
                for(it=0;it<WAVE;it=it+1) begin
                    // Mask padding and bypass bytes so external memory never
                    // needs to return the just-produced newest token.
                    if(new_q && o_kv_base+it==total_q-1) begin
                        keys_q[it*HEAD_DIM*32+:HEAD_DIM*32]<=new_k_q;
                        values_q[it*HEAD_DIM*32+:HEAD_DIM*32]<=new_v_q;
                    end else if(o_kv_base+it<total_q) begin
                        keys_q[it*HEAD_DIM*32+:HEAD_DIM*32]<=i_keys[it*HEAD_DIM*32+:HEAD_DIM*32];
                        values_q[it*HEAD_DIM*32+:HEAD_DIM*32]<=i_values[it*HEAD_DIM*32+:HEAD_DIM*32];
                    end else begin
                        keys_q[it*HEAD_DIM*32+:HEAD_DIM*32]<=0;
                        values_q[it*HEAD_DIM*32+:HEAD_DIM*32]<=0;
                    end
                end
                o_kv_wave_count<=o_kv_wave_count+1;
                if(state==S_LOAD) state<=S_LAUNCH;
                else prefetched_q<=1;
            end
            case(state)
                S_IDLE: if(i_cmd_valid && o_cmd_ready) begin
                    queries_q<=i_queries;first_q<=i_first_context;
                    total_q<=i_first_context+i_query_count-1;
                    count_q<=i_query_count;query_q<=0;base_q<=0;new_q<=i_new_kv;
                    new_k_q<=i_new_key;new_v_q<=i_new_value;
                    prefetched_q<=0;prefetch_open_q<=0;
                    o_cycle_count<=0;o_kv_wave_count<=0;
                    o_error<=i_query_count<1 || i_query_count>QUERY_BLOCK || i_first_context<1 ||
                        {1'b0,i_first_context}+i_query_count-1>MAX_CONTEXT ||
                        (i_new_kv && i_query_count!=1);
                    for(iq=0;iq<QUERY_BLOCK;iq=iq+1) present_q[iq]<=0;
                    if(i_query_count<1 || i_query_count>QUERY_BLOCK || i_first_context<1 ||
                       {1'b0,i_first_context}+i_query_count-1>MAX_CONTEXT ||
                       (i_new_kv && i_query_count!=1)) begin
                        results_q<=0;state<=S_RESPONSE;
                    end else begin append_pending_q<=i_new_kv;state<=S_SCALE; end
                end
                S_SCALE: state<=S_LOAD;
                S_LAUNCH: if(!query_skip) state<=S_WAIT;
                S_WAIT: if(all_merged) begin
                    for(ih=0;ih<GQA_GROUP;ih=ih+1) begin
                        present_q[query_q][ih]<=merged_present[ih];
                        m_q[query_q][ih]<=merged_m[ih];l_q[query_q][ih]<=merged_l[ih];
                        z_q[query_q][ih]<=merged_z[ih];
                    end
                    if(query_final) state<=S_INV;
                end
                S_INV: state<=S_NORMALIZE;
                S_NORMALIZE: results_q[query_q*GQA_GROUP*HEAD_DIM*32+:GQA_GROUP*HEAD_DIM*32]<=normalized;
                S_RESPONSE: if(i_ready) state<=S_IDLE;
                default: begin end
            endcase
            if(advance) begin
                if(query_q+1<count_q) begin query_q<=query_q+1;state<=S_LAUNCH;end
                else if(wave_final) state<=S_RESPONSE;
                else begin
                    base_q<=base_q+WAVE;query_q<=0;
                    prefetched_q<=0;prefetch_open_q<=0;
                    if(prefetched_q || (kv_accept && state!=S_LOAD)) state<=S_LAUNCH;
                    else state<=S_LOAD;
                end
            end
        end
    end
endmodule
