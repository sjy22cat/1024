# Attention SMIC 28nm 综合交付

主要综合对象是**单 query、单 head、16ctx×4dim FP32 Attention evaluator**。目标为完整 Attention 与扣除 QK/PV MAC 后的延迟 **ns**、标准单元面积 **µm²**、每命令能耗 **pJ**。
本次重建保留算法和调度，将 MAC 提取到独立 `u_mac` 层次，便于在同一映射实现中测量分项。
本机只有 Icarus 功能验证工具，没有执行 SMIC/Synopsys PPA；未测量项保留 PENDING。

## 上传什么

在本地生成：

```powershell
python Attention_confusion/parallel_row/synopsys/build_upload.py
```

**只需上传** `upload/attention_16x4_synopsys_upload.zip`。解压后进入 `attention_16x4_synopsys_upload/`，以该目录为工作目录。
展开包与 zip 内容一致；文件清单见 `UPLOAD_FILE_LIST.txt`，逐文件 SHA256 见 `UPLOAD_MANIFEST.json`。
不用上传整个仓库、SIM-1023、Excel 或历史结果。SMIC `.db/.lib`、Synopsys 官方 DesignWare 模型和许可证由服务器本地提供，不包含在压缩包内。

| 文件/目录 | 用途 |
|---|---|
| `sources.f` 与 7 个 `attention_*.sv` | 主对象及 GQA 扩展的可综合源码；综合时仅实例化指定顶层 |
| 3 个 `tb_attention_*.sv` | 主对象、GQA group、cohort 的数值及协议测试 |
| `verification/nonmac_tb_math.sv` | TB 的 FP32 编解码/独立实数参考辅助包；不进综合 |
| `synopsys/site.example.json` | 服务器库/模型路径、单位和时钟配置模板 |
| `synopsys/run_flow.py` | VCS/DC/PT/PrimePower 分阶段入口 |
| `synopsys/dc.tcl`, `pt.tcl`, `common.tcl`, `constraints.tcl` | 综合、STA、功耗和统一约束 |
| `synopsys/MEASUREMENT_CONTRACT.md` | 单 head、MAC 边界、同窗口计量及相减规则 |
| `synopsys/PROMPT_SYNOPSYS.md` | 可直接复制给服务器 Codex 的完整执行提示词 |
| `synopsys/measurement.template.json`, `collect_candidate.py` | 原始结果收集与审计字段 |
| `synopsys/subtract_mac.py`, `test_subtract_mac.py` | 测量返回后的相减和程序自测 |
| `verify_upload.py`, `UPLOAD_MANIFEST.json` | 上传完整性校验 |

**不含行为替代 DW 模型**。本地 `verification/nonmac_test_dw.sv` 只用于无许可证的功能回归，上传构建器明确排除它。

## 代码作用

| RTL | 作用 |
|---|---|
| `attention_qk_pv_mac_fp32.sv` | 新的 MAC 边界；QK/PV 分时复用乘法、注册归约树、四路维度合并及相关数据寄存器 |
| `attention_context_4dim_lane.sv` | 单 context lane，32 token×128 dim；控制 MAC，并执行局部 max/diff/exp/分母归约 |
| `attention_context_reduce_fp32.sv` | 16 个局部状态求统一最大值后并行重缩放、树形归约 |
| `attention_online_merge_fp32.sv` | 五级流水，将当前 wave 与历史 running 状态合并 |
| `attention_head_16ctx_4dim_eval.sv` | 本次主顶层；16 lane、并行 KV 装载及 merge 期间预取、query 缩放、最终归一化 |
| `attention_gqa_query_block_eval.sv` | 扩展：两个 Q head 共享一个 KV head，多个 query 分时计算；默认 QUERY_BLOCK=4，不能当作已测 query-block16 |
| `attention_gqa_cohort_eval.sv` | 扩展：8 个 KV group/16 个 Q head 的原子握手包装；不作本次默认面积/功耗对象 |

原始文件和旧上传包已备份到相邻 `Attention_confusion/_history/parallel_row_before_ppa_*/`。
根目录历史 `optimization_*.md` 和 `throughput_budget*.json` 仅供追溯，不能替代本次测量契约/新综合结果。

## 服务器如何运行

复制 [完整提示词](synopsys/PROMPT_SYNOPSYS.md) 给服务器 Codex，要求实际运行并处理工具版本差异。基础入口：

```bash
python3 verify_upload.py
cp synopsys/site.example.json synopsys/site.json
# 编辑真实 SMIC/DW 路径；核对 report_units 和库面积单位
python3 synopsys/run_flow.py --stage sim --contexts 128,512,513,1024,1152
python3 synopsys/run_flow.py --stage dc
python3 synopsys/run_flow.py --stage sta
python3 synopsys/run_flow.py --stage power
python3 synopsys/collect_candidate.py results/smic28_1ns
```

库角为 SCC28NHKCP_HSC35P140_RVT_V0p2 / RVT / SS / 0.9V / 125°C，初始目标周期1ns。约束见 `constraints.tcl`。
脚本是交付模板；本机无法确认服务器安装版本的命令/功率属性，服务器 Codex 应按 `help/man` 修正并保留 diff。
完整默认 FP32 网表非常大；若采用分层映射，仍需完整链接和全设计 STA/功耗，不得缩小参数后把结果写成默认实现。
主测量入口默认只运行主 TB。完整 N 扫描、边界协议及 GQA/cohort 回归步骤在提示词中，须另行执行并保存证据。
`collect_candidate.py` 仅收集 RAW 属性。必须审计单位、完整映射、层次聚合、窗口/活动覆盖及 STA，再形成 reviewed JSON；不能无证据地将 checks 批量改 true。

## 拿到结果后如何扣除 MAC

```bash
python3 synopsys/subtract_mac.py results/smic28_1ns/measurement_n1152.reviewed.json \
  --output results/smic28_1ns/nonmac_n1152.json
```

| 项目 | 相减口径 |
|---|---|
| 面积 | 同一完整网表的总叶单元面积 − 16 个互不重叠 `u_mac` 子树面积之和 |
| 动态能量 | 同一完整命令窗口的总动态能量 − 16 个 MAC 子树动态能量之和 |
| 漏电能量 | 同一完整命令窗口的总漏电能量 − 16 个 MAC 子树漏电能量之和 |
| 调度余项时间 | `(实测总周期 − QK阶段周期 − PV阶段周期) × 真实时钟周期` |

默认 N1152 的**预期周期**为总121、MAC42、余项79。只有真实通过1ns的 setup/hold/电气检查，才可将它们作为有效121/42/79ns。
余项时间含装载/控制；PV与分母求和重叠，79ns不是独立 Softmax 的关键路径延迟。纯非MAC算术预期72拍，另7拍为装载/启动/提交。
MAC面积/能量不能按42/121分摊，必须实测分区；merge/归一化里的乘法仍属于非MAC。
余项面积/能量包含寄存器 K/V bank 和共享控制，不等于只含 Softmax，也不能直接加到另计 buffer 的模拟器中。
请返回 reviewed JSON、`nonmac_nN.json`、`windows.json`、每个 MAC 的面积/功率记录和关键原始报告。数据返回后即可完成相减；本次不修改模拟器现有参数。

## 本地验证

仅在仓库内（有测试替代模型）运行：

```powershell
python Attention_confusion/parallel_row/verification/run_local.py
python Attention_confusion/parallel_row/synopsys/test_subtract_mac.py
```

这只能验证控制/数值与计量程序，不能证明 SMIC 1ns 时序或能耗。
