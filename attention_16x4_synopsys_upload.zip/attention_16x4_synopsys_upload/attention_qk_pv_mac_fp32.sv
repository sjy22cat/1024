`timescale 1ns/1ps
// Ownership boundary for QK/PV MAC arithmetic, operand selection and registers.
// K/V storage, query scale, Softmax and merge/normalization are outside.
// This is the SAME time-multiplexed datapath formerly inside the context lane.
module attention_qk_pv_mac_fp32 #(
    parameter integer TILE_SIZE=32, HEAD_DIM=128
) (
    input wire clk, rst_n, i_active,
    input wire [TILE_SIZE-1:0] i_mask,
    input wire i_mul, i_qk, i_tree, i_dim1, i_dim2,
    input wire [31:0] i_level,
    input wire [HEAD_DIM*32-1:0] i_query,
    input wire [TILE_SIZE*HEAD_DIM*32-1:0] i_key, i_value,
    input wire [TILE_SIZE*32-1:0] i_beta,
    output wire [TILE_SIZE*32-1:0] o_score,
    output wire [HEAD_DIM*32-1:0] o_z
);
    reg [31:0] mac_q [0:3][0:TILE_SIZE-1][1:2*TILE_SIZE-1];
    reg [31:0] dim_q [0:TILE_SIZE-1][0:1];
    reg [31:0] score_q [0:TILE_SIZE-1];
    wire [31:0] product [0:3][0:TILE_SIZE-1][0:TILE_SIZE-1];
    wire [31:0] mac_add [0:3][0:TILE_SIZE-1][1:TILE_SIZE-1];
    wire [31:0] dim_add [0:TILE_SIZE-1][0:2];
    genvar b,p,k,n;
    generate
        for (b=0;b<4;b=b+1) begin : g_block
            for (p=0;p<TILE_SIZE;p=p+1) begin : g_output
                assign o_z[(b*TILE_SIZE+p)*32+:32]=mac_q[b][p][1];
                for (k=0;k<TILE_SIZE;k=k+1) begin : g_mul
                    wire qk_valid=i_active && i_mask[p];
                    wire pv_valid=i_active && i_mask[k];
                    wire [31:0] a=i_qk ?
                        (qk_valid ? i_query[(b*TILE_SIZE+k)*32+:32] : 32'b0) :
                        ((i_mul && pv_valid) ? i_beta[k*32+:32] : 32'b0);
                    wire [31:0] v=i_qk ?
                        (qk_valid ? i_key[(p*HEAD_DIM+b*TILE_SIZE+k)*32+:32] : 32'b0) :
                        ((i_mul && pv_valid) ? i_value[(k*HEAD_DIM+b*TILE_SIZE+p)*32+:32] : 32'b0);
                    wire [7:0] status;
                    DW_fp_mult #(.sig_width(23),.exp_width(8),.ieee_compliance(0)) u_mul (
                        .a(a),.b(v),.rnd(3'b000),.z(product[b][p][k]),.status(status));
                end
                for (n=1;n<TILE_SIZE;n=n+1) begin : g_reduce
                    wire [7:0] status;
                    DW_fp_addsub #(.sig_width(23),.exp_width(8),.ieee_compliance(0)) u_add (
                        .a(mac_q[b][p][2*n]),.b(mac_q[b][p][2*n+1]),
                        .rnd(3'b000),.op(1'b0),.z(mac_add[b][p][n]),.status(status));
                end
            end
        end
        for (p=0;p<TILE_SIZE;p=p+1) begin : g_dim
            wire [7:0] s0,s1,s2;
            assign o_score[p*32+:32]=score_q[p];
            DW_fp_addsub #(.sig_width(23),.exp_width(8),.ieee_compliance(0)) u_a0 (
                .a(mac_q[0][p][1]),.b(mac_q[1][p][1]),.rnd(3'b000),.op(1'b0),.z(dim_add[p][0]),.status(s0));
            DW_fp_addsub #(.sig_width(23),.exp_width(8),.ieee_compliance(0)) u_a1 (
                .a(mac_q[2][p][1]),.b(mac_q[3][p][1]),.rnd(3'b000),.op(1'b0),.z(dim_add[p][1]),.status(s1));
            DW_fp_addsub #(.sig_width(23),.exp_width(8),.ieee_compliance(0)) u_a2 (
                .a(dim_q[p][0]),.b(dim_q[p][1]),.rnd(3'b000),.op(1'b0),.z(dim_add[p][2]),.status(s2));
        end
    endgenerate
    integer ib,ip,ik,inode;
    always @(posedge clk) if (rst_n) begin
        if (i_mul)
            for (ib=0;ib<4;ib=ib+1)
                for (ip=0;ip<TILE_SIZE;ip=ip+1)
                    for (ik=0;ik<TILE_SIZE;ik=ik+1)
                        mac_q[ib][ip][TILE_SIZE+ik]<=product[ib][ip][ik];
        if (i_tree)
            for (inode=1;inode<TILE_SIZE;inode=inode+1)
                if (inode >= (TILE_SIZE >> i_level) && inode < (TILE_SIZE >> (i_level-1)))
                    for (ib=0;ib<4;ib=ib+1)
                        for (ip=0;ip<TILE_SIZE;ip=ip+1)
                            mac_q[ib][ip][inode]<=mac_add[ib][ip][inode];
        if (i_dim1)
            for (ip=0;ip<TILE_SIZE;ip=ip+1) begin
                dim_q[ip][0]<=dim_add[ip][0];dim_q[ip][1]<=dim_add[ip][1];
            end
        if (i_dim2)
            for (ip=0;ip<TILE_SIZE;ip=ip+1) score_q[ip]<=dim_add[ip][2];
    end
endmodule
